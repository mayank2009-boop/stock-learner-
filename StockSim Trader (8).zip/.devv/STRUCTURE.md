# This file is only for editing file nodes, do not break the structure

/src
├── assets/          # Static resources directory, storing static files like images and fonts
│
├── components/      # Components directory
│   ├── ui/         # Pre-installed shadcn/ui components, avoid modifying or rewriting unless necessary
│   ├── layout/     # Layout components for page structure
│   │   └── MainLayout.tsx # Main layout component with navigation and footer
│   ├── stock/      # Stock-related components
│   │   ├── StockChart.tsx # Asset price chart component with multiple timeframe support
│   │   ├── ComparisonChart.tsx # Comparison chart for different asset types
│   │   ├── AssetTypePerformanceChart.tsx # Performance chart showing top assets within a specific asset type
│   │   └── Sparkline.tsx # Small line chart for stock price visualization
│   ├── insights/   # Market insights components
│   │   ├── StockNewsFeed.tsx # News feed component showing market news
│   │   └── StockList.tsx # List of assets with price information and type indicators
│   ├── learn/      # Learning module components
│   │   ├── LearningCard.tsx # Educational content card component
│   │   ├── QuizModal.tsx # Quiz modal component for testing knowledge
│   │   └── GlossaryTerms.tsx # Stock market glossary component
│   └── simulate/   # Simulation module components
│       ├── PortfolioSummary.tsx # Portfolio value and metrics component with asset allocation visualization
│       ├── TradePanel.tsx # Buy/sell interface for trading multiple asset types
│       ├── PortfolioHoldings.tsx # Table of owned assets with filtering capability
│       └── AssetCategorySelector.tsx # Selector for filtering assets by category
│
├── hooks/          # Custom Hooks directory
│   ├── use-mobile.ts # Pre-installed mobile detection Hook from shadcn (import { useIsMobile } from '@/hooks/use-mobile')
│   └── use-toast.ts  # Toast notification system hook for displaying toast messages (import { useToast } from '@/hooks/use-toast')
│
├── lib/            # Utility library directory
│   ├── utils.ts    # Utility functions, including the cn function for merging Tailwind class names
│   └── stock-data.ts # Asset data generation and simulation functions for multiple asset types
│
├── pages/          # Page components directory, based on React Router structure
│   ├── HomePage.tsx # Home page component with sectioned content areas and smooth scrolling navigation
│   └── NotFoundPage.tsx # 404 error page component, displays when users access non-existent routes
│
├── App.tsx         # Root component, with React Router routing system, redirecting section routes to homepage with appropriate state
│
├── main.tsx        # Entry file, rendering the root component and mounting to the DOM
│
├── index.css       # Global styles file, containing Tailwind configuration and custom styles
│                   # Modified theme colors for stock trading app
│
└── tailwind.config.js  # Tailwind CSS v3 configuration file
                      # Contains theme customization, plugins, and content paths
                      # Includes shadcn/ui theme configuration
