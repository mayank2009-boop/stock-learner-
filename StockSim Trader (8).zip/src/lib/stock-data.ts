export interface AssetData {
  symbol: string;
  name: string;
  price: number;
  change: number;
  changePercent: number;
  assetType: 'stock' | 'bond' | 'commodity' | 'etf' | 'mutual-fund';
  risk: 'low' | 'medium' | 'high';
  data: {
    time: string;
    price: number;
  }[];
  timeframeData: Record<string, { time: string; price: number }[]>;
}

export interface NewsItem {
  id: string;
  title: string;
  summary: string;
  category: string;
  time: string;
  impact: 'positive' | 'negative' | 'neutral';
  url?: string;
}

// Generate random asset price data
export const generateAssetData = (
  symbol: string, 
  name: string, 
  basePrice: number, 
  assetType: 'stock' | 'bond' | 'commodity' | 'etf' | 'mutual-fund',
  risk: 'low' | 'medium' | 'high' = 'medium',
  volatility = 0.02,
  timeframes = ['1D']
): AssetData => {
  // Generate data for each timeframe
  const timeframeData: Record<string, { time: string; price: number }[]> = {};
  
  const generateDataForTimeframe = (days: number, pointsPerDay: number, baseVol: number) => {
    let resultData: { time: string; price: number }[] = [];
    let lastPrice = basePrice;
    const totalPoints = days * pointsPerDay;
    const now = new Date();
    
    // Generate data points for the specified timeframe
    for (let i = totalPoints; i >= 0; i--) {
      // Adjust volatility based on asset type
      let assetVolatility = baseVol;
      if (assetType === 'bond') assetVolatility *= 0.3; // Bonds are less volatile
      if (assetType === 'stock') assetVolatility *= 1.2; // Stocks are more volatile
      if (assetType === 'commodity') assetVolatility *= 1.5; // Commodities can be quite volatile
      if (risk === 'low') assetVolatility *= 0.5;
      if (risk === 'high') assetVolatility *= 1.5;
      
      // Calculate time point
      const timeStep = (days * 24 * 60 * 60 * 1000) / totalPoints;
      const time = new Date(now.getTime() - i * timeStep).toISOString();
      
      // Calculate price change with some trend consistency
      const change = (Math.random() - 0.5) * assetVolatility * lastPrice;
      lastPrice = Math.max(lastPrice + change, 0.01); // Ensure price is positive
      
      resultData.push({
        time,
        price: parseFloat(lastPrice.toFixed(2)),
      });
    }
    
    return resultData;
  };
  
  // Generate data for different timeframes
  if (timeframes.includes('1D') || timeframes.length === 0) {
    timeframeData['1D'] = generateDataForTimeframe(1, 24, volatility);
  }
  if (timeframes.includes('1W')) {
    timeframeData['1W'] = generateDataForTimeframe(7, 4, volatility * 1.2);
  }
  if (timeframes.includes('1M')) {
    timeframeData['1M'] = generateDataForTimeframe(30, 1, volatility * 1.5);
  }
  if (timeframes.includes('6M')) {
    timeframeData['6M'] = generateDataForTimeframe(180, 0.2, volatility * 2);
  }
  if (timeframes.includes('1Y')) {
    timeframeData['1Y'] = generateDataForTimeframe(365, 0.1, volatility * 2.5);
  }
  
  // Use the default 1D timeframe for current display
  const data = timeframeData['1D'] || timeframeData[Object.keys(timeframeData)[0]];
  
  const currentPrice = data[data.length - 1].price;
  const previousPrice = data[data.length - 2].price;
  const change = currentPrice - previousPrice;
  const changePercent = (change / previousPrice) * 100;

  return {
    symbol,
    name,
    price: currentPrice,
    change,
    changePercent,
    assetType,
    risk,
    data,
    timeframeData
  };
};

// Generate simulated market data for all asset types
export const generateMarketData = (timeframes = ['1D', '1W', '1M', '6M', '1Y']): AssetData[] => {
  return [
    // Stocks
    generateAssetData('AAPL', 'Apple Inc.', 185.92, 'stock', 'medium', 0.02, timeframes),
    generateAssetData('MSFT', 'Microsoft Corp.', 420.21, 'stock', 'medium', 0.02, timeframes),
    generateAssetData('GOOGL', 'Alphabet Inc.', 174.50, 'stock', 'medium', 0.03, timeframes),
    generateAssetData('AMZN', 'Amazon.com Inc.', 178.75, 'stock', 'medium', 0.03, timeframes),
    generateAssetData('TSLA', 'Tesla, Inc.', 175.34, 'stock', 'high', 0.04, timeframes),
    generateAssetData('META', 'Meta Platforms Inc.', 482.16, 'stock', 'medium', 0.025, timeframes),
    generateAssetData('NVDA', 'NVIDIA Corp.', 950.02, 'stock', 'high', 0.05, timeframes),
    
    // Bonds
    generateAssetData('T10Y', '10-Year Treasury', 102.50, 'bond', 'low', 0.005, timeframes),
    generateAssetData('T5Y', '5-Year Treasury', 101.75, 'bond', 'low', 0.003, timeframes),
    generateAssetData('T2Y', '2-Year Treasury', 100.50, 'bond', 'low', 0.002, timeframes),
    generateAssetData('CORP1', 'Corporate Bond A', 98.25, 'bond', 'medium', 0.01, timeframes),
    generateAssetData('CORP2', 'Corporate Bond B', 97.50, 'bond', 'medium', 0.01, timeframes),
    
    // Commodities
    generateAssetData('GOLD', 'Gold', 2150.75, 'commodity', 'medium', 0.015, timeframes),
    generateAssetData('SILV', 'Silver', 28.50, 'commodity', 'medium', 0.02, timeframes),
    generateAssetData('OIL', 'Crude Oil', 78.25, 'commodity', 'high', 0.03, timeframes),
    
    // ETFs
    generateAssetData('SPY', 'S&P 500 ETF', 524.97, 'etf', 'medium', 0.01, timeframes),
    generateAssetData('QQQ', 'Nasdaq 100 ETF', 436.81, 'etf', 'medium', 0.015, timeframes),
    generateAssetData('VTI', 'Total Market ETF', 252.43, 'etf', 'medium', 0.01, timeframes),
    generateAssetData('AGG', 'Bond Market ETF', 108.12, 'etf', 'low', 0.005, timeframes),
    
    // Mutual Funds
    generateAssetData('VFINX', 'Vanguard 500 Index', 325.42, 'mutual-fund', 'medium', 0.008, timeframes),
    generateAssetData('FXAIX', 'Fidelity 500 Index', 174.35, 'mutual-fund', 'medium', 0.008, timeframes),
    generateAssetData('PIMIX', 'PIMCO Income Fund', 11.28, 'mutual-fund', 'low', 0.004, timeframes),
    generateAssetData('VBTLX', 'Vanguard Total Bond', 10.12, 'mutual-fund', 'low', 0.003, timeframes)
  ];
};

// Generate simulated news data
export const generateNewsData = (): NewsItem[] => {
  return [
    {
      id: '1',
      title: 'S&P 500 rises after positive inflation report',
      summary: 'The market responded positively to inflation numbers coming in lower than analyst expectations.',
      category: 'Market Update',
      time: '35 minutes ago',
      impact: 'positive',
    },
    {
      id: '2',
      title: 'Tech sector shows strength amid economic concerns',
      summary: 'Technology stocks continue to perform well despite broader economic uncertainty.',
      category: 'Sector News',
      time: '2 hours ago',
      impact: 'positive',
    },
    {
      id: '3',
      title: 'Federal Reserve signals potential interest rate cuts',
      summary: 'The Fed chairman indicated the possibility of rate cuts later this year if inflation continues to moderate.',
      category: 'Economic Policy',
      time: '4 hours ago',
      impact: 'positive',
    },
    {
      id: '4',
      title: 'Oil prices drop on increased supply concerns',
      summary: 'Crude oil prices fell 3% following reports of increased production from major suppliers.',
      category: 'Commodities',
      time: '6 hours ago',
      impact: 'negative',
    },
    {
      id: '5',
      title: 'Gold reaches new highs as investors seek safe havens',
      summary: 'Gold prices continue to climb amid global economic uncertainty and inflation concerns.',
      category: 'Commodities',
      time: '7 hours ago',
      impact: 'positive',
    },
    {
      id: '6',
      title: 'Bond yields fall as investors anticipate Fed policy shift',
      summary: 'Treasury yields declined across the curve as markets price in potential interest rate cuts.',
      category: 'Bonds',
      time: '9 hours ago',
      impact: 'neutral',
    },
    {
      id: '7',
      title: 'ETF inflows reach record levels for the quarter',
      summary: 'Exchange-traded funds saw unprecedented investor interest, particularly in broad market and sector-specific options.',
      category: 'ETFs',
      time: '1 day ago',
      impact: 'positive',
    },
  ];
};

// Educational content for the Learn section
export const educationalTopics = [
  {
    id: 'stocks-basics',
    title: 'What are Stocks?',
    description: 'Learn the fundamentals of stocks and how they represent ownership in a company.',
    content: `
      <p>A stock (also known as a share) represents a small ownership stake in a company. When you buy a stock, you're buying a piece of that business.</p>
      <p>Companies issue stocks to raise money for operations, expansion, or other business needs. Investors buy these stocks hoping that:</p>
      <ul>
        <li>The company will grow and become more valuable over time</li>
        <li>The stock price will increase, allowing them to sell at a profit</li>
        <li>The company might pay dividends (a portion of profits distributed to shareholders)</li>
      </ul>
      <p>Stock prices change constantly during market hours based on supply and demand. Various factors affect stock prices including company performance, economic conditions, industry trends, and investor sentiment.</p>
    `,
  },
  {
    id: 'bonds-basics',
    title: 'Understanding Bonds',
    description: 'Learn how bonds work as fixed-income investments and their role in portfolios.',
    content: `
      <p>Bonds are fixed-income securities that represent loans made by investors to borrowers, typically corporations or governments.</p>
      <p>When you buy a bond, you're essentially lending money to the issuer for a specified period at a specific interest rate. Key bond characteristics include:</p>
      <ul>
        <li><strong>Face Value:</strong> The amount returned when the bond matures (typically $1,000)</li>
        <li><strong>Coupon Rate:</strong> The annual interest payment expressed as a percentage of face value</li>
        <li><strong>Maturity Date:</strong> When the principal amount is returned to the bondholder</li>
        <li><strong>Yield:</strong> The total return expected if held to maturity</li>
      </ul>
      <p>Bonds generally offer lower risk and lower returns than stocks, making them attractive for income-focused investors and those seeking to balance portfolio risk.</p>
      <p>Bond prices move inversely to interest rates—when rates rise, bond prices fall, and vice versa.</p>
    `,
  },
  {
    id: 'commodities-basics',
    title: 'Investing in Commodities',
    description: 'Understand how commodity investments work and their role in diversification.',
    content: `
      <p>Commodities are physical goods that are interchangeable with other goods of the same type. Major commodity categories include:</p>
      <ul>
        <li><strong>Precious Metals:</strong> Gold, silver, platinum</li>
        <li><strong>Energy:</strong> Crude oil, natural gas</li>
        <li><strong>Agricultural:</strong> Wheat, corn, soybeans</li>
        <li><strong>Industrial Metals:</strong> Copper, aluminum</li>
      </ul>
      <p>Investors typically gain exposure to commodities through:</p>
      <ul>
        <li><strong>Futures contracts:</strong> Agreements to buy or sell a commodity at a predetermined price at a future date</li>
        <li><strong>ETFs/ETNs:</strong> Funds that track commodity prices or indexes</li>
        <li><strong>Physical ownership:</strong> Directly holding commodities like gold or silver</li>
        <li><strong>Commodity-focused stocks:</strong> Investing in companies that produce or process commodities</li>
      </ul>
      <p>Commodities often have low correlation with stocks and bonds, potentially providing portfolio diversification. They can also serve as a hedge against inflation.</p>
    `,
  },
  {
    id: 'etfs-basics',
    title: 'Exchange-Traded Funds (ETFs)',
    description: 'Learn how ETFs provide diversification and flexibility for investors.',
    content: `
      <p>Exchange-Traded Funds (ETFs) are investment funds traded on stock exchanges that hold assets such as stocks, bonds, or commodities.</p>
      <p>Key features of ETFs include:</p>
      <ul>
        <li><strong>Diversification:</strong> A single ETF can hold hundreds or thousands of individual securities</li>
        <li><strong>Intraday Trading:</strong> Unlike mutual funds, ETFs can be bought and sold throughout the trading day at market prices</li>
        <li><strong>Lower Costs:</strong> Many ETFs have lower expense ratios than comparable mutual funds</li>
        <li><strong>Tax Efficiency:</strong> ETFs generally generate fewer capital gains taxes than mutual funds</li>
        <li><strong>Transparency:</strong> Most ETFs disclose their holdings daily</li>
      </ul>
      <p>ETFs can track various market segments, including broad market indices (like the S&P 500), specific sectors, geographic regions, investment styles, or even specific investment strategies.</p>
      <p>They provide an efficient way for beginners to gain broad market exposure with relatively small investment amounts.</p>
    `,
  },
  {
    id: 'mutual-funds-basics',
    title: 'Mutual Funds Explained',
    description: 'Understand how mutual funds work and their benefits for long-term investors.',
    content: `
      <p>Mutual funds pool money from many investors to purchase a diversified portfolio of securities, managed by professional investment managers.</p>
      <p>Key characteristics of mutual funds include:</p>
      <ul>
        <li><strong>Professional Management:</strong> Fund managers research and select investments based on the fund's objectives</li>
        <li><strong>Diversification:</strong> Even with a small investment, you gain exposure to many different securities</li>
        <li><strong>Daily Pricing:</strong> Mutual fund shares are priced once per day after market close (Net Asset Value or NAV)</li>
        <li><strong>Minimum Investments:</strong> Many funds require minimum initial investments (often $1,000-$3,000)</li>
        <li><strong>Fund Types:</strong> Include equity (stock) funds, bond funds, balanced funds, index funds, and specialty funds</li>
      </ul>
      <p>Mutual funds are particularly suitable for long-term investors who prefer a hands-off approach, as the fund manager handles security selection, rebalancing, and other investment decisions.</p>
      <p>When evaluating mutual funds, consider factors such as expense ratios, performance history, fund manager tenure, and how the fund fits with your investment goals.</p>
    `,
  },
  {
    id: 'buy-sell',
    title: 'Buying and Selling Stocks',
    description: 'Understand the basics of stock trading, including how to place orders.',
    content: `
      <p>To buy or sell stocks, you'll need a brokerage account. Today, many online platforms make this process simple.</p>
      <h4>Common Order Types:</h4>
      <ul>
        <li><strong>Market Order:</strong> Buy or sell at the current available price</li>
        <li><strong>Limit Order:</strong> Buy or sell only at a specified price or better</li>
        <li><strong>Stop Order:</strong> Becomes a market order when a specified price is reached</li>
      </ul>
      <p>When buying stocks, consider:</p>
      <ul>
        <li>Your investment goals and time horizon</li>
        <li>How the stock fits into your overall portfolio</li>
        <li>The company's financial health and growth prospects</li>
        <li>Current valuation relative to earnings and future potential</li>
      </ul>
      <p>Remember that all investing involves risk, including the potential loss of principal.</p>
    `,
  },
  {
    id: 'portfolio',
    title: 'Building a Portfolio',
    description: 'Learn how to create a diversified investment portfolio to manage risk.',
    content: `
      <p>A portfolio is your collection of investments. Diversification—spreading investments across different assets—is key to managing risk.</p>
      <h4>Portfolio Components:</h4>
      <ul>
        <li><strong>Stocks:</strong> Ownership in companies (higher growth potential, higher risk)</li>
        <li><strong>Bonds:</strong> Loans to companies or governments (lower risk, steady income)</li>
        <li><strong>ETFs/Mutual Funds:</strong> Baskets of investments offering instant diversification</li>
        <li><strong>Cash/Equivalents:</strong> Money market funds, savings (safety and liquidity)</li>
      </ul>
      <p>Your portfolio mix depends on:</p>
      <ul>
        <li>Your age and time horizon</li>
        <li>Risk tolerance</li>
        <li>Financial goals</li>
      </ul>
      <p>Beginners often start with index funds or ETFs that track major market indices like the S&P 500, providing broad market exposure with a single purchase.</p>
    `,
  },
  {
    id: 'candlesticks',
    title: 'Reading Candlestick Charts',
    description: 'Decode candlestick charts to understand price movements and market sentiment.',
    content: `
      <p>Candlestick charts display price movements in a visually rich format, showing the open, close, high, and low prices for a specific period.</p>
      <h4>Candlestick Anatomy:</h4>
      <ul>
        <li><strong>Body:</strong> The rectangle showing the open and close prices</li>
        <li><strong>Wick/Shadow:</strong> The thin lines showing price extremes</li>
        <li><strong>Green/White Candle:</strong> Close price higher than open (bullish)</li>
        <li><strong>Red/Black Candle:</strong> Close price lower than open (bearish)</li>
      </ul>
      <h4>Common Patterns:</h4>
      <ul>
        <li><strong>Doji:</strong> Open and close prices are nearly equal, suggesting indecision</li>
        <li><strong>Hammer:</strong> Short body with long lower wick, potential reversal signal</li>
        <li><strong>Engulfing:</strong> Current candle completely "engulfs" the previous one</li>
      </ul>
      <p>Candlesticks are valuable tools for technical analysis but work best when combined with other indicators and fundamental analysis.</p>
    `,
  },
  {
    id: 'risk-management',
    title: 'Risk Management',
    description: 'Learn essential strategies to protect your investments and minimize losses.',
    content: `
      <p>Risk management is crucial for long-term investment success. It involves strategies to protect your capital while pursuing returns.</p>
      <h4>Key Risk Management Strategies:</h4>
      <ul>
        <li><strong>Diversification:</strong> Spread investments across different assets, sectors, and geographies</li>
        <li><strong>Position Sizing:</strong> Limit how much you invest in any single position</li>
        <li><strong>Stop-Loss Orders:</strong> Automatically sell if a stock falls to a predetermined price</li>
        <li><strong>Dollar-Cost Averaging:</strong> Invest fixed amounts regularly regardless of market conditions</li>
        <li><strong>Rebalancing:</strong> Periodically adjust portfolio allocations back to target percentages</li>
      </ul>
      <p>Remember that even the best risk management can't eliminate all investment risk, but it can help you avoid catastrophic losses and maintain focus on long-term goals.</p>
    `,
  },
];

// Quiz questions for testing knowledge
export const quizQuestions = [
  {
    id: '1',
    topic: 'stocks-basics',
    question: 'What does owning a stock represent?',
    options: [
      'A loan to a company',
      'Ownership in a company',
      'A promise from a company to pay dividends',
      'A guaranteed return on investment'
    ],
    correctAnswer: 1, // Index of correct answer
    explanation: 'When you own a stock, you own a small piece of that company. This makes you a shareholder with certain rights, including potential profits through price appreciation and dividends.'
  },
  {
    id: '2',
    topic: 'buy-sell',
    question: 'What type of order guarantees execution but not price?',
    options: [
      'Limit order',
      'Stop order',
      'Market order',
      'Fill-or-kill order'
    ],
    correctAnswer: 2,
    explanation: 'A market order executes immediately at the best available current price. It guarantees execution but not the price you\'ll receive.'
  },
  {
    id: '3',
    topic: 'portfolio',
    question: 'Why is diversification important in a portfolio?',
    options: [
      'It guarantees higher returns',
      'It eliminates all investment risk',
      'It helps manage risk by spreading investments across different assets',
      'It ensures you always beat market averages'
    ],
    correctAnswer: 2,
    explanation: 'Diversification helps manage risk by spreading investments across different asset classes, sectors, and companies. This reduces the impact of poor performance from any single investment on your overall portfolio.'
  },
  {
    id: '4',
    topic: 'bonds-basics',
    question: 'What happens to bond prices when interest rates rise?',
    options: [
      'Bond prices rise',
      'Bond prices fall',
      'Bond prices remain unchanged',
      'It depends on the bond issuer'
    ],
    correctAnswer: 1,
    explanation: 'Bond prices and interest rates have an inverse relationship. When interest rates rise, existing bonds with lower rates become less attractive, causing their prices to fall.'
  },
  {
    id: '5',
    topic: 'commodities-basics',
    question: 'Which of the following is NOT a common way to invest in commodities?',
    options: [
      'Futures contracts',
      'ETFs that track commodity prices',
      'Dividend reinvestment plans',
      'Stocks of commodity-producing companies'
    ],
    correctAnswer: 2,
    explanation: 'Dividend reinvestment plans (DRIPs) are associated with stock investments, not commodities. Common ways to invest in commodities include futures contracts, ETFs, physical ownership, and stocks of companies that produce commodities.'
  },
  {
    id: '6',
    topic: 'etfs-basics',
    question: 'What is an advantage of ETFs compared to mutual funds?',
    options: [
      'ETFs can only be traded once per day',
      'ETFs always have lower expense ratios',
      'ETFs can be bought and sold throughout the trading day',
      'ETFs are always actively managed'
    ],
    correctAnswer: 2,
    explanation: 'Unlike mutual funds which trade only once per day at the closing NAV price, ETFs can be bought and sold throughout the trading day at market prices, offering more trading flexibility.'
  },
  {
    id: '7',
    topic: 'mutual-funds-basics',
    question: 'When are mutual fund shares priced each day?',
    options: [
      'At market open',
      'Throughout the trading day',
      'After market close',
      'Before market open the following day'
    ],
    correctAnswer: 2,
    explanation: 'Mutual fund shares are priced once per day after the market closes. The price, called Net Asset Value (NAV), is calculated by dividing the total value of all the fund\'s assets by the number of outstanding shares.'
  },
  {
    id: '8',
    topic: 'candlesticks',
    question: 'In a candlestick chart, what does a green candle typically represent?',
    options: [
      'The price closed lower than it opened',
      'The price closed higher than it opened',
      'The price didn\'t change during the period',
      'Trading volume was higher than average'
    ],
    correctAnswer: 1,
    explanation: 'A green (or white) candlestick indicates that the closing price was higher than the opening price, showing buyers were in control during that time period.'
  },
  {
    id: '9',
    topic: 'risk-management',
    question: 'What is the purpose of a stop-loss order?',
    options: [
      'To automatically buy more shares when prices fall',
      'To limit potential losses by selling at a predetermined price',
      'To maximize profits by selling at peak prices',
      'To prevent other investors from buying your shares'
    ],
    correctAnswer: 1,
    explanation: 'A stop-loss order is designed to limit an investor\'s potential loss on a position by triggering a sale when the stock reaches a predetermined price level.'
  },
];

// Asset-specific tooltips for trading simulator
export const assetTypeTooltips = {
  stock: 'Stocks represent ownership in a company. They offer potential for capital appreciation and sometimes dividends, but can be volatile.',
  bond: 'Bonds are fixed-income securities that represent loans to governments or corporations. They typically provide regular interest payments and return of principal at maturity.',
  commodity: 'Commodities are physical goods like gold, silver, or oil. They can serve as a hedge against inflation and provide portfolio diversification.',
  etf: 'Exchange-Traded Funds (ETFs) are investment funds traded on stock exchanges, holding assets like stocks, bonds, or commodities. They offer diversification with the trading flexibility of stocks.',
  'mutual-fund': 'Mutual funds pool money from many investors to purchase a diversified portfolio of securities managed by professionals. They\'re priced once daily after market close.'
};

// Glossary of stock market terms
export const glossaryTerms = [
  {
    term: 'Bull Market',
    definition: 'A market condition in which prices are rising or expected to rise. Generally refers to a time when stock prices rise by 20% or more from recent lows.'
  },
  {
    term: 'Bear Market',
    definition: 'A market condition in which prices are falling or expected to fall. Generally refers to a time when stock prices fall by 20% or more from recent highs.'
  },
  {
    term: 'Dividend',
    definition: 'A portion of a company\'s earnings paid to shareholders, usually in cash but sometimes in additional stock.'
  },
  {
    term: 'P/E Ratio',
    definition: 'Price-to-Earnings Ratio. A valuation metric calculated by dividing a company\'s current stock price by its earnings per share. Indicates how much investors are willing to pay for each dollar of earnings.'
  },
  {
    term: 'Market Cap',
    definition: 'Market Capitalization. The total value of a company\'s outstanding shares, calculated by multiplying the stock price by the total number of shares outstanding.'
  },
  {
    term: 'Volatility',
    definition: 'A statistical measure of the dispersion of returns for a given security or market index. Higher volatility means higher risk as prices can change dramatically over a short time period.'
  },
  {
    term: 'ETF',
    definition: 'Exchange-Traded Fund. An investment fund traded on stock exchanges that holds assets such as stocks, bonds, or commodities, and typically aims to track the performance of an index.'
  },
  {
    term: 'Mutual Fund',
    definition: 'An investment vehicle that pools money from many investors to purchase a portfolio of stocks, bonds, or other securities, managed by professional fund managers.'
  },
  {
    term: 'Bond Yield',
    definition: 'The return an investor realizes on a bond. Current yield is a bond\'s annual interest payment divided by its current market price.'
  },
  {
    term: 'Commodity Futures',
    definition: 'Standardized contracts for the purchase and sale of physical commodities for future delivery on a regulated commodity futures exchange.'
  },
  {
    term: 'Liquidity',
    definition: 'The degree to which an asset can be quickly bought or sold without affecting its price. Cash is the most liquid asset, while real estate is considered relatively illiquid.'
  },
  {
    term: 'Capital Gain',
    definition: 'The profit realized when selling an investment for a higher price than the purchase price.'
  },
  {
    term: 'Blue Chip',
    definition: 'A nationally recognized, well-established, and financially sound company with a history of reliable performance and dividend payments.'
  }
];

// Simulated user portfolio for the trading simulator
export const initialPortfolio = {
  cash: 10000, // $10,000 starting cash
  positions: [], // Will contain asset positions as they're purchased
  transactions: [] // Will contain history of trades
};

// Calculate portfolio value
export const calculatePortfolioValue = (portfolio: any, marketData: AssetData[]) => {
  const assetValue = portfolio.positions.reduce((total: number, position: any) => {
    const asset = marketData.find(s => s.symbol === position.symbol);
    return total + (asset ? asset.price * position.shares : 0);
  }, 0);
  
  return {
    cash: portfolio.cash,
    assetValue,
    totalValue: portfolio.cash + assetValue
  };
};