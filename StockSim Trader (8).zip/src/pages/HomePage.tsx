import React, { useState, useEffect } from 'react';
import { useAssetStore } from '@/store/asset-store';
import { useLocation } from 'react-router-dom';
import MainLayout from '@/components/layout/MainLayout';
import AssetChart from '@/components/stock/StockChart';
import ComparisonChart from '@/components/stock/ComparisonChart';
import AssetTypePerformanceChart from '@/components/stock/AssetTypePerformanceChart';
import StockList from '@/components/insights/StockList';
import StockNewsFeed from '@/components/insights/StockNewsFeed';
import LearningCard from '@/components/learn/LearningCard';
import GlossaryTerms from '@/components/learn/GlossaryTerms';
import QuizModal from '@/components/learn/QuizModal';
import PortfolioSummary from '@/components/simulate/PortfolioSummary';
import TradePanel from '@/components/simulate/TradePanel';
import PortfolioHoldings from '@/components/simulate/PortfolioHoldings';
import AssetCategorySelector from '@/components/simulate/AssetCategorySelector';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  generateMarketData, 
  generateNewsData, 
  educationalTopics, 
  AssetData,
  initialPortfolio,
  calculatePortfolioValue,
  assetTypeTooltips
} from '@/lib/stock-data';
import { 
  GraduationCap, 
  TrendingUp, 
  HelpCircle, 
  BarChart2, 
  ArrowRight,
  Info
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardHeader, CardTitle, CardContent, CardDescription, CardFooter } from '@/components/ui/card';
import { Tooltip, TooltipTrigger, TooltipContent, TooltipProvider } from '@/components/ui/tooltip';
import { Badge } from '@/components/ui/badge';
import { useToast } from '@/hooks/use-toast';

function HomePage() {
  const [marketData, setMarketData] = useState<AssetData[]>([]);
  const [newsData, setNewsData] = useState(generateNewsData());
  const [activeTab, setActiveTab] = useState('learn');
  // Use the shared asset store for state management
  const { selectedAsset, setSelectedAsset, selectedAssetType, setSelectedAssetType, timeframe, setTimeframe } = useAssetStore();
  const [quizOpen, setQuizOpen] = useState(false);
  const [currentQuizTopic, setCurrentQuizTopic] = useState('');
  const [portfolio, setPortfolio] = useState(initialPortfolio);
  const [assetCategory, setAssetCategory] = useState('all');
  // No longer needed as we use the asset store
  // No longer needed as we use the asset store
  const { toast } = useToast();
  const location = useLocation();
  const [isDarkMode, setIsDarkMode] = useState(false);
  // We now use the shared selectedAsset from the store for both sections

  // Check if dark mode is enabled
  useEffect(() => {
    const darkModeCheck = () => {
      setIsDarkMode(document.documentElement.classList.contains('dark'));
    };
    
    // Check initial state
    darkModeCheck();
    
    // Create a MutationObserver to watch for class changes on html element
    const observer = new MutationObserver((mutations) => {
      mutations.forEach((mutation) => {
        if (mutation.attributeName === 'class') {
          darkModeCheck();
        }
      });
    });
    
    observer.observe(document.documentElement, { attributes: true });
    
    return () => observer.disconnect();
  }, []);

  // Set active tab based on location state (for navigation from other pages)
  useEffect(() => {
    if (location.state && location.state.activeTab) {
      setActiveTab(location.state.activeTab);
      
      // Smooth scroll to section after a short delay to ensure it's rendered
      setTimeout(() => {
        const section = document.getElementById(location.state.activeTab);
        if (section) {
          section.scrollIntoView({ behavior: 'smooth' });
        }
      }, 100);
      
      // Clear the state to prevent it from persisting on refresh
      window.history.replaceState({}, document.title);
    }
  }, [location.state]);
  
  // Observer for scroll-based navigation highlighting
  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            // Update active tab based on visible section
            setActiveTab(entry.target.id);
          }
        });
      },
      { threshold: 0.6 } // Trigger when section is 60% visible
    );

    // Observe all section elements
    const sections = document.querySelectorAll('section[id]');
    sections.forEach((section) => {
      observer.observe(section);
    });

    return () => {
      sections.forEach((section) => {
        observer.unobserve(section);
      });
    };
  }, []);

  // Generate initial market data with all timeframes
  useEffect(() => {
    const data = generateMarketData(['1D', '1W', '1M', '6M', '1Y']);
    setMarketData(data);
    setSelectedAsset(data[0]); // Default to first asset - will be used for both simulator and market insight
  }, []);

  // Filter assets based on selected category
  const filteredAssets = marketData.filter(asset => {
    if (assetCategory === 'all') return true;
    if (assetCategory === 'etf-mutual') return asset.assetType === 'etf' || asset.assetType === 'mutual-fund';
    return asset.assetType === assetCategory;
  });

  // Get representative assets for comparison chart (one of each type)
  const getComparisonAssets = () => {
    const stockAsset = marketData.find(a => a.assetType === 'stock');
    const bondAsset = marketData.find(a => a.assetType === 'bond');
    const commodityAsset = marketData.find(a => a.assetType === 'commodity');
    const etfAsset = marketData.find(a => a.assetType === 'etf');
    const mutualFundAsset = marketData.find(a => a.assetType === 'mutual-fund');
    
    return [
      stockAsset, 
      bondAsset, 
      commodityAsset, 
      etfAsset, 
      mutualFundAsset
    ].filter(Boolean) as AssetData[];
  };

  // Refresh market data (simulated)
  const refreshMarketData = () => {
    const newData = generateMarketData(['1D', '1W', '1M', '6M', '1Y']);
    setMarketData(newData);
    
    // Update selected assets with new data
    if (selectedAsset) {
      const updatedAsset = newData.find(a => a.symbol === selectedAsset.symbol);
      if (updatedAsset) {
        setSelectedAsset(updatedAsset);
      }
    }
    
    // Both charts now use the same data source from the store
  };

  // Start a quiz for a topic
  const handleStartQuiz = (topicId: string) => {
    setCurrentQuizTopic(topicId);
    setQuizOpen(true);
  };

  // Handle tab change with smooth scrolling
  const handleTabChange = (value: string) => {
    setActiveTab(value);
    
    // Smooth scroll to section
    const section = document.getElementById(value);
    if (section) {
      section.scrollIntoView({ behavior: 'smooth' });
    }
  };

  // Handle trades
  const handleTrade = (type: 'buy' | 'sell', symbol: string, shares: number, price: number) => {
    setPortfolio(prev => {
      const newPortfolio = { ...prev };
      
      // Get asset type for the position
      const assetType = marketData.find(a => a.symbol === symbol)?.assetType || 'stock';
      
      if (type === 'buy') {
        // Deduct cash
        newPortfolio.cash -= shares * price;
        
        // Add to positions
        const existingPosition = newPortfolio.positions.find(p => p.symbol === symbol);
        if (existingPosition) {
          // Update existing position
          const totalShares = existingPosition.shares + shares;
          const newAvgPrice = ((existingPosition.shares * existingPosition.avgPrice) + (shares * price)) / totalShares;
          existingPosition.shares = totalShares;
          existingPosition.avgPrice = newAvgPrice;
        } else {
          // Create new position
          newPortfolio.positions.push({
            symbol,
            shares,
            avgPrice: price,
            assetType
          });
        }
      } else {
        // Add cash
        newPortfolio.cash += shares * price;
        
        // Reduce position
        const existingPosition = newPortfolio.positions.find(p => p.symbol === symbol);
        if (existingPosition) {
          existingPosition.shares -= shares;
          
          // Remove position if no shares left
          if (existingPosition.shares <= 0) {
            newPortfolio.positions = newPortfolio.positions.filter(p => p.symbol !== symbol);
          }
        }
      }
      
      // Add to transaction history
      newPortfolio.transactions.push({
        type,
        symbol,
        shares,
        price,
        timestamp: new Date().toISOString(),
        assetType
      });
      
      return newPortfolio;
    });
  };

  // Calculate portfolio metrics
  const portfolioValue = calculatePortfolioValue(portfolio, marketData);

  // Get owned shares for selected asset
  const getOwnedShares = (symbol: string) => {
    const position = portfolio.positions.find(p => p.symbol === symbol);
    return position ? position.shares : 0;
  };

  // Calculate asset allocation for portfolio
  const calculateAssetAllocation = () => {
    // Skip if no assets in portfolio
    if (portfolio.positions.length === 0) return [];
    
    // Group positions by asset type and sum values
    const allocation: Record<string, number> = {};
    
    portfolio.positions.forEach(position => {
      const asset = marketData.find(a => a.symbol === position.symbol);
      if (asset) {
        const type = asset.assetType;
        const value = position.shares * asset.price;
        
        if (allocation[type]) {
          allocation[type] += value;
        } else {
          allocation[type] = value;
        }
      }
    });
    
    // Convert to array format
    return Object.entries(allocation).map(([type, value]) => ({ type, value }));
  };

  // Handle asset type change for performance chart
  const handleAssetTypeChange = (type: string) => {
    setSelectedAssetType(type);
  };

  return (
    <MainLayout setActiveTab={setActiveTab} activeTab={activeTab}>
      {/* Hero Section */}
      <section id="home" className="relative gradient-header text-white py-10 md:py-16">
        <div className="container">
          <div className="max-w-2xl space-y-4">
            <h1 className="text-3xl md:text-4xl font-bold tracking-tight">Learn Trading Without Risk</h1>
            <p className="text-base md:text-lg text-white/80">
              Practice trading skills with virtual money in a beginner-friendly environment.
              Learn about stocks, bonds, commodities, ETFs, and mutual funds.
            </p>
            <div className="flex flex-wrap gap-3 pt-2">
              <Button 
                onClick={() => handleTabChange('learn')} 
                size="lg" 
                className={`rounded-button btn-hover-effect ${isDarkMode ? 'btn-primary-dark' : 'btn-primary-light'}`}
                id="start-learning-button"
                aria-label="Start Learning"
              >
                <GraduationCap className="h-5 w-5 mr-2" /> Start Learning
              </Button>
              <Button 
                onClick={() => handleTabChange('simulate')} 
                size="lg" 
                className={`rounded-button btn-hover-effect ${isDarkMode ? 'btn-secondary-dark' : 'btn-secondary-light'}`}
                id="try-simulator-button"
                aria-label="Try Trading Simulator"
              >
                <TrendingUp className="h-5 w-5 mr-2" /> Try Trading Simulator
              </Button>
            </div>
          </div>
        </div>
        <div className="absolute inset-0 bg-[url('https://images.unsplash.com/photo-1642543492481-44e81e3914a7?w=1200&h=600&fit=crop')] opacity-10 bg-center bg-cover"></div>
      </section>

      {/* Tab Navigation */}
      <div className="sticky top-14 z-40 w-full bg-background border-b">
        <div className="container py-2">
          <Tabs value={activeTab} onValueChange={handleTabChange}>
            <TabsList className="grid w-full max-w-lg mx-auto grid-cols-4">
              <TabsTrigger value="learn" className="flex items-center gap-1.5">
                <GraduationCap className="h-4 w-4 md:mr-1" />
                <span className="hidden sm:inline">Learn</span>
                <span className="sm:hidden">Learn</span>
              </TabsTrigger>
              <TabsTrigger value="simulate" className="flex items-center gap-1.5">
                <TrendingUp className="h-4 w-4 md:mr-1" />
                <span className="hidden sm:inline">Simulate</span>
                <span className="sm:hidden">Sim</span>
              </TabsTrigger>
              <TabsTrigger value="insights" className="flex items-center gap-1.5">
                <BarChart2 className="h-4 w-4 md:mr-1" />
                <span className="hidden sm:inline">Market Insights</span>
                <span className="sm:hidden">Insights</span>
              </TabsTrigger>
              <TabsTrigger value="quiz" className="flex items-center gap-1.5">
                <HelpCircle className="h-4 w-4 md:mr-1" />
                <span className="hidden sm:inline">Quiz</span>
                <span className="sm:hidden">Quiz</span>
              </TabsTrigger>
            </TabsList>
          </Tabs>
        </div>
      </div>

      {/* Learn Section */}
      <section id="learn" className="py-8 md:py-12 bg-muted/50">
        <div className="container">
          <h2 className="text-2xl md:text-3xl font-bold mb-6 md:mb-8">Learn Trading</h2>
          
          <div className="grid gap-6 md:gap-8 md:grid-cols-2">
            {educationalTopics.slice(0, 2).map(topic => (
              <LearningCard
                key={topic.id}
                id={topic.id}
                title={topic.title}
                description={topic.description}
                content={topic.content}
                onQuizStart={handleStartQuiz}
              />
            ))}
          </div>

          <div className="grid gap-6 md:gap-8 md:grid-cols-2 lg:grid-cols-3 mt-6 md:mt-8">
            {educationalTopics.slice(2, 5).map(topic => (
              <LearningCard
                key={topic.id}
                id={topic.id}
                title={topic.title}
                description={topic.description}
                content={topic.content}
                onQuizStart={handleStartQuiz}
              />
            ))}
          </div>
          
          <div className="mt-6 md:mt-8">
            <Card className="shadow-md">
              <CardHeader className="pb-2 md:pb-4">
                <CardTitle>Asset Types Comparison</CardTitle>
                <CardDescription>Understand the differences between various investment options</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4 md:space-y-6">
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3 md:gap-4">
                  {Object.entries(assetTypeTooltips).map(([type, description]) => (
                    <Card key={type} className="shadow-sm">
                      <CardHeader className="py-3 md:py-4">
                        <CardTitle className="text-base capitalize">
                          {type === 'etf' ? 'ETF' : type.replace('-', ' ')}
                        </CardTitle>
                      </CardHeader>
                      <CardContent className="py-2">
                        <p className="text-sm text-muted-foreground">{description}</p>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
          
          <div className="pt-6">
            <GlossaryTerms />
          </div>
        </div>
      </section>

      {/* Simulate Section */}
      <section id="simulate" className="py-8 md:py-12">
        <div className="container">
          <h2 className="text-2xl md:text-3xl font-bold mb-6 md:mb-8">Trading Simulator</h2>
          <div className="grid gap-6 md:gap-8 lg:grid-cols-3">
            <div className="lg:col-span-2">
              <PortfolioSummary 
                cash={portfolioValue.cash} 
                assetValue={portfolioValue.assetValue} 
                totalValue={portfolioValue.totalValue}
                assetAllocation={calculateAssetAllocation()}
              />
            </div>
            <div>
              <AssetCategorySelector 
                selectedCategory={assetCategory}
                onCategoryChange={setAssetCategory}
              />
              
              <div className="mt-4">
                <Card className="shadow-md">
                  <CardHeader className="pb-2">
                    <CardTitle className="text-lg flex justify-between items-center">
                      <span>Available Assets</span>
                      <TooltipProvider>
                        <Tooltip>
                          <TooltipTrigger asChild>
                            <div className="cursor-help flex items-center">
                              <Info className="h-4 w-4 text-muted-foreground" />
                            </div>
                          </TooltipTrigger>
                          <TooltipContent side="top">
                            <p className="max-w-xs">Select an asset to view its chart and trading options</p>
                          </TooltipContent>
                        </Tooltip>
                      </TooltipProvider>
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="max-h-[320px] overflow-y-auto pr-1">
                      {filteredAssets.map(asset => (
                        <div
                          key={asset.symbol}
                          className={`flex items-center justify-between p-3 mb-1 rounded-lg cursor-pointer ${
                            selectedAsset?.symbol === asset.symbol 
                              ? 'bg-primary/10 border border-primary/20' 
                              : 'hover:bg-muted'
                          }`}
                          onClick={() => setSelectedAsset(asset)}
                        >
                          <div>
                            <div className="flex items-center gap-2">
                              <span className="font-medium">{asset.symbol}</span>
                              <Badge 
                                variant="outline" 
                                className={`text-xs py-0 h-5 ${asset.assetType === 'etf' ? 'text-etf' : ''}`}
                              >
                                {asset.assetType === 'etf' ? 'ETF' : asset.assetType.charAt(0).toUpperCase() + asset.assetType.replace('-', ' ').slice(1)}
                              </Badge>
                            </div>
                            <p className="text-xs text-muted-foreground mt-1 line-clamp-1">{asset.name}</p>
                          </div>
                          <div className="text-right">
                            <div className="font-medium">${asset.price.toFixed(2)}</div>
                            <div className={asset.change >= 0 ? "text-profit text-xs" : "text-loss text-xs"}>
                              {asset.change >= 0 ? "+" : ""}{asset.change.toFixed(2)} ({asset.change >= 0 ? "+" : ""}{asset.changePercent.toFixed(2)}%)
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>
          </div>

          {/* Live Price Chart - in the simulator section */}
          <div className="mt-6 mb-6">
            {selectedAsset && (
              <AssetChart 
                assetData={selectedAsset} 
                refreshData={refreshMarketData}
                chartId="simulator-chart"
              />
            )}
          </div>

          <div className="grid gap-6 md:gap-8 lg:grid-cols-3 mt-6 md:mt-8">
            <div className="lg:col-span-2">
              <div className="responsive-table-wrapper">
                <PortfolioHoldings 
                  positions={portfolio.positions} 
                  marketData={marketData}
                  onSelectAsset={setSelectedAsset}
                />
              </div>
            </div>
            <div>
              {selectedAsset && (
                <TradePanel 
                  selectedAsset={selectedAsset}
                  availableCash={portfolio.cash}
                  onTrade={handleTrade}
                  ownedShares={getOwnedShares(selectedAsset.symbol)}
                />
              )}
            </div>
          </div>
        </div>
      </section>

      {/* Market Insights Section */}
      <section id="insights" className="py-8 md:py-12 bg-muted/50">
        <div className="container">
          <h2 className="text-2xl md:text-3xl font-bold mb-6 md:mb-8">Market Insights</h2>
          
          {/* Live Chart in Market Insights section */}
          <div className="mb-6 md:mb-8">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-4">
              <h3 className="text-xl font-semibold">Live Asset Chart</h3>
              <div className="flex gap-2 overflow-x-auto pb-2 sm:pb-0">
                {getComparisonAssets().map((asset) => (
                  <Button
                    key={asset.symbol}
                    variant={selectedAsset?.symbol === asset.symbol ? "secondary" : "outline"}
                    size="sm"
                    onClick={() => setSelectedAsset(asset)}
                    className="whitespace-nowrap"
                  >
                    {asset.symbol}
                    <Badge 
                      variant="outline" 
                      className={`ml-1.5 text-xs py-0 h-5 ${asset.assetType === 'etf' ? 'text-etf' : ''}`}
                    >
                      {asset.assetType === 'etf' ? 'ETF' : asset.assetType.charAt(0).toUpperCase() + asset.assetType.replace('-', ' ').slice(1)}
                    </Badge>
                  </Button>
                ))}
              </div>
            </div>
            {selectedAsset && (
              <AssetChart 
                assetData={selectedAsset} 
                refreshData={refreshMarketData}
                chartId="market-insight-chart"
              />
            )}
          </div>
          
          {/* Asset performance charts positioned next */}
          <div className="mb-6 md:mb-8">
            <AssetTypePerformanceChart assets={marketData} />
          </div>
          
          <div className="mb-6 md:mb-8">
            <ComparisonChart 
              assets={getComparisonAssets()}
              selectedAssetType={selectedAssetType}
              onAssetTypeChange={setSelectedAssetType}
            />
          </div>
          
          <div className="grid gap-6 md:gap-8 md:grid-cols-2">
            <div>
              <StockList 
                stocks={marketData} 
                onSelectStock={(asset) => {
                  setSelectedAsset(asset);
                  // No need to set market insight asset separately
                }}
              />
              
              <div className="mt-4 grid gap-4 grid-cols-1 sm:grid-cols-2">
                {marketData.slice(0, 4).map(asset => (
                  <Card key={asset.symbol} className="shadow-sm">
                    <CardHeader className="pb-1 md:pb-2">
                      <CardTitle className="text-sm flex items-center justify-between">
                        <span className="flex items-center gap-1">
                          {asset.symbol}
                          <Badge 
                            variant="outline" 
                            className={`ml-1 text-xs py-0 h-5 ${asset.assetType === 'etf' ? 'text-etf' : ''}`}
                          >
                            {asset.assetType === 'etf' ? 'ETF' : asset.assetType.charAt(0).toUpperCase() + asset.assetType.slice(1)}
                          </Badge>
                        </span>
                        <span>${asset.price.toFixed(2)}</span>
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="pt-0">
                      <div className="flex justify-between items-center">
                        <p className="text-xs text-muted-foreground line-clamp-1">{asset.name}</p>
                        <span className={asset.change >= 0 ? "text-profit text-xs" : "text-loss text-xs"}>
                          {asset.change >= 0 ? "+" : ""}{asset.changePercent.toFixed(2)}%
                        </span>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
            <div>
              <StockNewsFeed news={newsData} />
            </div>
          </div>
        </div>
      </section>

      {/* Quiz Section */}
      <section id="quiz" className="py-8 md:py-12">
        <div className="container">
          <h2 className="text-2xl md:text-3xl font-bold mb-6 md:mb-8">Test Your Knowledge</h2>
          
          <div className="grid gap-4 md:gap-6">
            {educationalTopics.map(topic => (
              <Card 
                key={topic.id}
                className="p-6 rounded-lg border bg-card flex flex-col justify-between hover:shadow-md transition-shadow"
              >
                <div>
                  <h3 className="text-lg font-semibold">{topic.title}</h3>
                  <p className="text-muted-foreground mt-1">{topic.description}</p>
                </div>
                <Button 
                  className="mt-4 w-full sm:w-auto"
                  onClick={() => handleStartQuiz(topic.id)}
                >
                  Start Quiz <ArrowRight className="w-4 h-4 ml-2" />
                </Button>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Quiz Modal */}
      <QuizModal
        open={quizOpen}
        onOpenChange={setQuizOpen}
        topicId={currentQuizTopic}
      />
    </MainLayout>
  );
}

export default HomePage;