import { create } from 'zustand';
import { AssetData } from '@/lib/stock-data';

interface AssetStore {
  // Selected asset in the simulator section
  selectedAsset: AssetData | null;
  // Selected asset type for comparison charts
  selectedAssetType: string;
  // Selected timeframe
  timeframe: '1D' | '1W' | '1M' | '6M' | '1Y';
  
  // Actions
  setSelectedAsset: (asset: AssetData | null) => void;
  setSelectedAssetType: (type: string) => void;
  setTimeframe: (timeframe: '1D' | '1W' | '1M' | '6M' | '1Y') => void;
}

export const useAssetStore = create<AssetStore>((set) => ({
  selectedAsset: null,
  selectedAssetType: 'etf',
  timeframe: '1D',
  
  setSelectedAsset: (asset) => set({ selectedAsset: asset }),
  setSelectedAssetType: (type) => set({ selectedAssetType: type }),
  setTimeframe: (timeframe) => set({ timeframe })
}));