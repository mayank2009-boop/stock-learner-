import React, { useState } from 'react';
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { GraduationCap, Lightbulb, BookOpen, ChevronDown, ChevronUp } from 'lucide-react';
import { Badge } from '@/components/ui/badge';

interface LearningCardProps {
  id: string;
  title: string;
  description: string;
  content: string;
  onQuizStart?: (topicId: string) => void;
}

const LearningCard: React.FC<LearningCardProps> = ({
  id,
  title,
  description,
  content,
  onQuizStart,
}) => {
  const [expanded, setExpanded] = useState(false);

  return (
    <Card className="shadow-md">
      <CardHeader>
        <div className="flex justify-between items-center">
          <CardTitle className="flex items-center gap-2">
            <GraduationCap className="h-5 w-5 text-primary" />
            {title}
          </CardTitle>
          <Badge variant="outline" className="bg-primary/10">
            Beginner
          </Badge>
        </div>
        <CardDescription>{description}</CardDescription>
      </CardHeader>

      <CardContent>
        {expanded ? (
          <div dangerouslySetInnerHTML={{ __html: content }} className="prose prose-sm max-w-none" />
        ) : (
          <div className="relative overflow-hidden max-h-24">
            <div dangerouslySetInnerHTML={{ __html: content.slice(0, 150) + '...' }} className="prose prose-sm max-w-none" />
            <div className="absolute bottom-0 left-0 right-0 h-12 bg-gradient-to-t from-background to-transparent"></div>
          </div>
        )}
      </CardContent>

      <CardFooter className="flex justify-between pt-2">
        <Button variant="ghost" onClick={() => setExpanded(!expanded)}>
          {expanded ? (
            <>
              <ChevronUp className="mr-1 h-4 w-4" /> Show Less
            </>
          ) : (
            <>
              <ChevronDown className="mr-1 h-4 w-4" /> Read More
            </>
          )}
        </Button>

        {onQuizStart && (
          <Button onClick={() => onQuizStart(id)} variant="default">
            <BookOpen className="mr-1 h-4 w-4" /> Take Quiz
          </Button>
        )}
      </CardFooter>
    </Card>
  );
};

export default LearningCard;