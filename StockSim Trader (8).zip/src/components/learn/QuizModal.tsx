import React, { useState } from 'react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Label } from '@/components/ui/label';
import { quizQuestions } from '@/lib/stock-data';
import { CheckCircle, XCircle, RotateCw } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

interface QuizModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  topicId: string;
}

const QuizModal: React.FC<QuizModalProps> = ({ open, onOpenChange, topicId }) => {
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null);
  const [submittedAnswer, setSubmittedAnswer] = useState<number | null>(null);
  const [isCorrect, setIsCorrect] = useState<boolean | null>(null);
  const { toast } = useToast();

  // Get questions for the current topic
  const topicQuestions = quizQuestions.filter(q => q.topic === topicId);
  const currentQuestion = topicQuestions.length > 0 ? topicQuestions[0] : null;

  const handleSubmit = () => {
    if (selectedAnswer === null || !currentQuestion) return;
    
    setSubmittedAnswer(selectedAnswer);
    const correct = selectedAnswer === currentQuestion.correctAnswer;
    setIsCorrect(correct);
    
    if (correct) {
      toast({
        title: "Correct!",
        description: "Great job! You got the right answer.",
      });
    }
  };

  const resetQuiz = () => {
    setSelectedAnswer(null);
    setSubmittedAnswer(null);
    setIsCorrect(null);
  };

  if (!currentQuestion) {
    return (
      <Dialog open={open} onOpenChange={onOpenChange}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>No quiz available</DialogTitle>
            <DialogDescription>
              There are no quiz questions available for this topic yet.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button onClick={() => onOpenChange(false)}>Close</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    );
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-lg">
        <DialogHeader>
          <DialogTitle>Test Your Knowledge</DialogTitle>
          <DialogDescription>
            Answer the question below to test your understanding.
          </DialogDescription>
        </DialogHeader>

        <div className="py-4">
          <h3 className="text-lg font-medium mb-4">{currentQuestion.question}</h3>

          <RadioGroup value={selectedAnswer?.toString()} onValueChange={(value) => setSelectedAnswer(parseInt(value))}>
            {currentQuestion.options.map((option, index) => (
              <div 
                key={index} 
                className={`flex items-center space-x-2 p-3 rounded-md border mb-2 ${
                  submittedAnswer !== null && index === currentQuestion.correctAnswer
                    ? 'border-green-500 bg-green-50 dark:bg-green-950/20'
                    : submittedAnswer === index && submittedAnswer !== currentQuestion.correctAnswer
                    ? 'border-red-500 bg-red-50 dark:bg-red-950/20'
                    : ''
                }`}
              >
                <RadioGroupItem 
                  value={index.toString()} 
                  id={`option-${index}`}
                  disabled={submittedAnswer !== null}
                />
                <Label htmlFor={`option-${index}`} className="flex-grow">{option}</Label>
                {submittedAnswer !== null && index === currentQuestion.correctAnswer && (
                  <CheckCircle className="h-5 w-5 text-green-500" />
                )}
                {submittedAnswer === index && submittedAnswer !== currentQuestion.correctAnswer && (
                  <XCircle className="h-5 w-5 text-red-500" />
                )}
              </div>
            ))}
          </RadioGroup>

          {submittedAnswer !== null && (
            <div className="mt-4 p-4 rounded-md bg-muted">
              <h4 className="font-medium mb-1">Explanation</h4>
              <p className="text-sm">{currentQuestion.explanation}</p>
            </div>
          )}
        </div>

        <DialogFooter>
          {submittedAnswer === null ? (
            <Button 
              onClick={handleSubmit}
              disabled={selectedAnswer === null}
            >
              Submit Answer
            </Button>
          ) : (
            <div className="flex gap-2">
              <Button 
                variant="outline" 
                onClick={resetQuiz}
              >
                <RotateCw className="mr-2 h-4 w-4" />
                Try Again
              </Button>
              <Button onClick={() => onOpenChange(false)}>
                Finish
              </Button>
            </div>
          )}
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

export default QuizModal;