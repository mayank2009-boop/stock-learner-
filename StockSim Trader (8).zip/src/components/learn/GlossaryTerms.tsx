import React from 'react';
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from '@/components/ui/accordion';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { glossaryTerms } from '@/lib/stock-data';
import { BookOpen } from 'lucide-react';

const GlossaryTerms: React.FC = () => {
  return (
    <Card className="shadow-md">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <BookOpen className="h-5 w-5" />
          Stock Market Glossary
        </CardTitle>
        <CardDescription>
          Essential terms and definitions for beginners
        </CardDescription>
      </CardHeader>
      <CardContent>
        <Accordion type="single" collapsible className="w-full">
          {glossaryTerms.map((term, index) => (
            <AccordionItem key={index} value={`term-${index}`}>
              <AccordionTrigger className="text-left font-medium">
                {term.term}
              </AccordionTrigger>
              <AccordionContent className="text-muted-foreground">
                {term.definition}
              </AccordionContent>
            </AccordionItem>
          ))}
        </Accordion>
      </CardContent>
    </Card>
  );
};

export default GlossaryTerms;