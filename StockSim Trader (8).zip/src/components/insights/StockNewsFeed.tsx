import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { NewsItem } from '@/lib/stock-data';
import { ArrowUpRight, ArrowDownRight, Minus, RefreshCw, ExternalLink } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { useToast } from '@/hooks/use-toast';

interface StockNewsFeedProps {
  news: NewsItem[];
}

const StockNewsFeed: React.FC<StockNewsFeedProps> = ({ news: initialNews }) => {
  const [news, setNews] = useState<NewsItem[]>(initialNews);
  const [isLoading, setIsLoading] = useState(false);
  const [lastUpdated, setLastUpdated] = useState<Date>(new Date());
  const { toast } = useToast();

  const getImpactIcon = (impact: 'positive' | 'negative' | 'neutral') => {
    switch (impact) {
      case 'positive':
        return <ArrowUpRight className="h-4 w-4 text-profit" />;
      case 'negative':
        return <ArrowDownRight className="h-4 w-4 text-loss" />;
      case 'neutral':
        return <Minus className="h-4 w-4 text-muted-foreground" />;
    }
  };

  const getImpactClass = (impact: 'positive' | 'negative' | 'neutral') => {
    switch (impact) {
      case 'positive':
        return 'bg-profit/10 text-profit';
      case 'negative':
        return 'bg-loss/10 text-loss';
      default:
        return 'bg-muted text-muted-foreground';
    }
  };

  // Generate a valid URL for each news item
  const getNewsUrl = (item: NewsItem) => {
    // Use the title and ID to create a slug for the URL
    const baseUrl = "https://stocklearn-news.example.com/articles";
    const titleSlug = item.title
      .toLowerCase()
      .replace(/[^\w\s]/g, '')
      .replace(/\s+/g, '-');
    
    return `${baseUrl}/${titleSlug}-${item.id}`;
  };

  // Function to fetch the latest news
  const fetchLatestNews = async () => {
    setIsLoading(true);
    try {
      // In a real implementation, this would be an API call
      // For simulation, we'll just wait a bit and generate new news
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      // Simulate new news items
      const newNewsItems: NewsItem[] = [
        {
          id: `news-${Date.now()}-1`,
          title: 'Breaking: Market reacts to latest economic data',
          summary: 'Investors digest new employment figures and consumer spending data released today.',
          category: 'Economic Data',
          time: 'Just now',
          impact: Math.random() > 0.5 ? 'positive' : 'negative',
          url: 'https://stocklearn-news.example.com/breaking-economic-data'
        },
        {
          id: `news-${Date.now()}-2`,
          title: 'Tech sector leads market rally amid positive earnings',
          summary: 'Major technology companies report better than expected quarterly results.',
          category: 'Earnings',
          time: '5 minutes ago',
          impact: 'positive',
          url: 'https://stocklearn-news.example.com/tech-sector-rally'
        },
        ...news.slice(0, 5).map(item => ({
          ...item,
          url: item.url || getNewsUrl(item)
        })), // Keep some previous news and ensure they have URLs
      ];
      
      setNews(newNewsItems);
      setLastUpdated(new Date());
      
      toast({
        title: "News Updated",
        description: "Latest market news has been loaded"
      });
    } catch (error) {
      toast({
        title: "Failed to update news",
        description: "Could not fetch the latest market news",
        variant: "destructive"
      });
    } finally {
      setIsLoading(false);
    }
  };

  // Auto-refresh news every 5 minutes
  useEffect(() => {
    const interval = setInterval(fetchLatestNews, 5 * 60 * 1000);
    return () => clearInterval(interval);
  }, [news]);

  // Add URLs to any news items that don't have them
  useEffect(() => {
    setNews(prevNews => 
      prevNews.map(item => ({
        ...item,
        url: item.url || getNewsUrl(item)
      }))
    );
  }, []);

  // Format the last updated time
  const formatLastUpdated = () => {
    return lastUpdated.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  };

  // Handle news item click
  const handleNewsClick = (url: string) => {
    window.open(url, '_blank', 'noopener noreferrer');
  };

  return (
    <Card className="shadow-md h-full">
      <CardHeader className="pb-2 flex flex-col sm:flex-row sm:items-center justify-between">
        <div>
          <CardTitle className="text-lg sm:text-xl">Market News</CardTitle>
          <CardDescription className="flex items-center gap-1">
            Latest market updates and headlines
            <span className="text-xs text-muted-foreground ml-1">
              (Last updated: {formatLastUpdated()})
            </span>
          </CardDescription>
        </div>
        <Button 
          variant="outline" 
          size="sm" 
          onClick={fetchLatestNews} 
          disabled={isLoading}
          className="mt-2 sm:mt-0"
          aria-label="Refresh news feed"
        >
          <RefreshCw className={`h-4 w-4 mr-1 ${isLoading ? 'animate-spin' : ''}`} />
          Refresh
        </Button>
      </CardHeader>
      <CardContent className="space-y-4 overflow-y-auto max-h-[500px]">
        {news.map((item) => (
          <div 
            key={item.id} 
            className="border-b pb-4 last:border-b-0 last:pb-0 news-item-clickable rounded-md p-2"
            onClick={() => handleNewsClick(item.url || getNewsUrl(item))}
            role="button"
            aria-label={`Read news article: ${item.title}`}
            tabIndex={0}
            onKeyDown={(e) => {
              if (e.key === 'Enter' || e.key === ' ') {
                e.preventDefault();
                handleNewsClick(item.url || getNewsUrl(item));
              }
            }}
          >
            <div className="flex items-start justify-between gap-2">
              <div className="flex-1 min-w-0">
                <h4 className="font-medium line-clamp-2 hover:text-primary transition-colors flex items-start gap-1 group">
                  {item.title}
                  <ExternalLink className="h-3.5 w-3.5 opacity-50 group-hover:opacity-100 transition-opacity flex-shrink-0 mt-0.5" />
                </h4>
                <p className="text-sm text-muted-foreground mt-1 line-clamp-2">{item.summary}</p>
              </div>
              <div className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full">
                {getImpactIcon(item.impact)}
              </div>
            </div>
            <div className="flex flex-wrap items-center justify-between mt-2 gap-2">
              <Badge className={`text-xs ${getImpactClass(item.impact)}`}>
                {item.category}
              </Badge>
              <span className="text-xs text-muted-foreground">{item.time}</span>
            </div>
          </div>
        ))}
        
        {news.length === 0 && !isLoading && (
          <div className="text-center py-8">
            <p className="text-muted-foreground">No news available</p>
          </div>
        )}
        
        {isLoading && news.length === 0 && (
          <div className="text-center py-8">
            <RefreshCw className="h-8 w-8 mx-auto animate-spin text-muted-foreground" />
            <p className="mt-2 text-muted-foreground">Loading news...</p>
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default StockNewsFeed;