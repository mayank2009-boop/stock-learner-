import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Table, TableBody, TableCaption, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { AssetData } from '@/lib/stock-data';
import { Badge } from '@/components/ui/badge';
import { ArrowUpDown } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';

interface StockListProps {
  stocks: AssetData[];
  onSelectStock?: (stock: AssetData) => void;
}

const StockList: React.FC<StockListProps> = ({ stocks, onSelectStock }) => {
  const [sortConfig, setSortConfig] = useState<{ key: string; direction: 'ascending' | 'descending' }>({
    key: 'symbol',
    direction: 'ascending',
  });
  const [filter, setFilter] = useState('');

  // Get sorted and filtered stocks
  const getSortedAndFilteredStocks = () => {
    let sortableStocks = [...stocks];
    
    // Filter by name, symbol, or type
    if (filter) {
      const lowerFilter = filter.toLowerCase();
      sortableStocks = sortableStocks.filter(stock => 
        stock.symbol.toLowerCase().includes(lowerFilter) || 
        stock.name.toLowerCase().includes(lowerFilter) ||
        stock.assetType.toLowerCase().includes(lowerFilter)
      );
    }
    
    // Sort based on current config
    sortableStocks.sort((a, b) => {
      if ((a as any)[sortConfig.key] < (b as any)[sortConfig.key]) {
        return sortConfig.direction === 'ascending' ? -1 : 1;
      }
      if ((a as any)[sortConfig.key] > (b as any)[sortConfig.key]) {
        return sortConfig.direction === 'ascending' ? 1 : -1;
      }
      return 0;
    });
    
    return sortableStocks;
  };

  // Request sort based on key
  const requestSort = (key: string) => {
    let direction: 'ascending' | 'descending' = 'ascending';
    if (sortConfig.key === key && sortConfig.direction === 'ascending') {
      direction = 'descending';
    }
    setSortConfig({ key, direction });
  };

  const formatAssetType = (type: string) => {
    switch (type) {
      case 'stock':
        return 'Stock';
      case 'bond':
        return 'Bond';
      case 'commodity':
        return 'Commodity';
      case 'etf':
        return 'ETF'; // Keep ETF uppercase
      case 'mutual-fund':
        return 'Mutual Fund';
      default:
        return type.charAt(0).toUpperCase() + type.slice(1).replace('-', ' ');
    }
  };

  const getAssetTypeColor = (type: string) => {
    switch (type) {
      case 'stock':
        return 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-300';
      case 'bond':
        return 'bg-purple-100 text-purple-800 dark:bg-purple-900 dark:text-purple-300';
      case 'commodity':
        return 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-300';
      case 'etf':
        return 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300 text-etf';
      case 'mutual-fund':
        return 'bg-pink-100 text-pink-800 dark:bg-pink-900 dark:text-pink-300';
      default:
        return 'bg-gray-100 text-gray-800 dark:bg-gray-800 dark:text-gray-300';
    }
  };

  return (
    <Card className="shadow-md">
      <CardHeader>
        <CardTitle className="text-lg">Market Overview</CardTitle>
        <div className="mt-2">
          <Input 
            placeholder="Search assets..." 
            value={filter} 
            onChange={(e) => setFilter(e.target.value)}
            className="max-w-sm"
          />
        </div>
      </CardHeader>
      <CardContent>
        <div className="responsive-table-wrapper">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead className="w-[100px]">
                  <Button 
                    variant="ghost" 
                    className="px-0 font-medium flex items-center"
                    onClick={() => requestSort('symbol')}
                  >
                    Symbol <ArrowUpDown className="ml-1 h-4 w-4" />
                  </Button>
                </TableHead>
                <TableHead className="hidden sm:table-cell max-w-[150px]">
                  <Button 
                    variant="ghost" 
                    className="px-0 font-medium flex items-center"
                    onClick={() => requestSort('name')}
                  >
                    Name <ArrowUpDown className="ml-1 h-4 w-4" />
                  </Button>
                </TableHead>
                <TableHead className="hidden md:table-cell">
                  <Button 
                    variant="ghost" 
                    className="px-0 font-medium flex items-center"
                    onClick={() => requestSort('assetType')}
                  >
                    Type <ArrowUpDown className="ml-1 h-4 w-4" />
                  </Button>
                </TableHead>
                <TableHead className="text-right">
                  <Button 
                    variant="ghost" 
                    className="px-0 font-medium flex items-center ml-auto"
                    onClick={() => requestSort('price')}
                  >
                    Price <ArrowUpDown className="ml-1 h-4 w-4" />
                  </Button>
                </TableHead>
                <TableHead className="text-right">
                  <Button 
                    variant="ghost" 
                    className="px-0 font-medium flex items-center ml-auto"
                    onClick={() => requestSort('changePercent')}
                  >
                    <span className="hidden xs:inline">Change</span> % <ArrowUpDown className="ml-1 h-4 w-4" />
                  </Button>
                </TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {getSortedAndFilteredStocks().slice(0, 10).map((stock) => (
                <TableRow 
                  key={stock.symbol}
                  className={onSelectStock ? 'cursor-pointer hover:bg-muted/50' : ''}
                  onClick={() => onSelectStock && onSelectStock(stock)}
                >
                  <TableCell className="font-medium">{stock.symbol}</TableCell>
                  <TableCell className="hidden sm:table-cell max-w-[150px]">
                    <span className="line-clamp-1">{stock.name}</span>
                  </TableCell>
                  <TableCell className="hidden md:table-cell">
                    <Badge 
                      variant="secondary" 
                      className={`whitespace-nowrap text-xs ${getAssetTypeColor(stock.assetType)}`}
                    >
                      {formatAssetType(stock.assetType)}
                    </Badge>
                  </TableCell>
                  <TableCell className="text-right">${stock.price.toFixed(2)}</TableCell>
                  <TableCell className={stock.changePercent >= 0 ? "text-profit text-right" : "text-loss text-right"}>
                    {stock.changePercent >= 0 ? "+" : ""}{stock.changePercent.toFixed(2)}%
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      </CardContent>
    </Card>
  );
};

export default StockList;