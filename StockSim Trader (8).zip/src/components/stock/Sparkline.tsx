import React from 'react';
import { Line } from 'react-chartjs-2';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Tooltip,
  Filler
} from 'chart.js';

// Register Chart.js components
ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Tooltip,
  Filler
);

interface SparklineProps {
  data: number[];
  height?: number;
  width?: number;
  positive?: boolean;
}

const Sparkline: React.FC<SparklineProps> = ({ 
  data, 
  height = 40, 
  width = 120,
  positive
}) => {
  // Determine if trend is positive (if not explicitly provided)
  const isPositive = positive !== undefined 
    ? positive 
    : data[data.length - 1] >= data[0];

  const chartData = {
    labels: Array(data.length).fill(''),
    datasets: [
      {
        data,
        borderColor: isPositive ? 'hsl(var(--profit))' : 'hsl(var(--loss))',
        backgroundColor: isPositive 
          ? 'rgba(39, 174, 96, 0.1)' 
          : 'rgba(231, 76, 60, 0.1)',
        borderWidth: 1.5,
        tension: 0.4,
        fill: true,
        pointRadius: 0,
        pointHoverRadius: 0,
      }
    ]
  };

  const chartOptions = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        display: false,
      },
      tooltip: {
        enabled: false,
      },
    },
    scales: {
      x: {
        display: false,
      },
      y: {
        display: false,
      }
    },
    elements: {
      point: {
        radius: 0,
      },
    },
  };

  return (
    <div style={{ height: `${height}px`, width: `${width}px` }}>
      <Line data={chartData} options={chartOptions} />
    </div>
  );
};

export default Sparkline;