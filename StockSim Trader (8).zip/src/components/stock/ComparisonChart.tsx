import React, { useState } from 'react';
import { Line } from 'react-chartjs-2';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend,
} from 'chart.js';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { AssetData } from '@/lib/stock-data';
import { Tabs, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { useIsMobile } from '@/hooks/use-mobile';
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from "@/components/ui/select";

// Register Chart.js components
ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend
);

interface ComparisonChartProps {
  assets: AssetData[];
  selectedAssetType?: string;
  onAssetTypeChange?: (type: string) => void;
}

const ComparisonChart: React.FC<ComparisonChartProps> = ({ 
  assets,
  selectedAssetType,
  onAssetTypeChange
}) => {
  const [timeframe, setTimeframe] = useState<'1M' | '6M' | '1Y'>('1M');
  const isMobile = useIsMobile();
  const [localAssetType, setLocalAssetType] = useState<string | undefined>(selectedAssetType || 'all');

  // Handle asset type changes
  const handleAssetTypeChange = (type: string) => {
    setLocalAssetType(type);
    if (onAssetTypeChange) {
      onAssetTypeChange(type);
    }
  };

  // Get unique asset types from assets
  const assetTypes = ['all', ...Array.from(new Set(assets.map(asset => asset.assetType)))];

  // Filter assets by selected type
  const filteredAssets = localAssetType === 'all' 
    ? assets 
    : assets.filter(asset => asset.assetType === localAssetType);

  // Get assets for comparison chart - take up to 5 assets
  const comparisonAssets = filteredAssets.slice(0, 5);

  // Get color for asset type
  const getAssetColor = (assetType: string, index: number) => {
    const colors = {
      'stock': '#4299E1',      // Blue
      'bond': '#805AD5',       // Purple
      'commodity': '#F6E05E',  // Yellow
      'etf': '#68D391',        // Green
      'mutual-fund': '#F687B3', // Pink
    };
    
    return (colors as any)[assetType] || [
      '#4299E1', '#805AD5', '#F6E05E', '#68D391', '#F687B3'
    ][index % 5];
  };

  // Get the dataset for a specific asset
  const getAssetDataset = (asset: AssetData, index: number) => {
    if (!asset.timeframeData || !asset.timeframeData[timeframe]) {
      return null;
    }

    const data = asset.timeframeData[timeframe];
    
    // Calculate percentage change from first data point
    const firstValue = data[0].price;
    const normalizedData = data.map(point => {
      const percentChange = ((point.price - firstValue) / firstValue) * 100;
      return {
        time: point.time,
        percentChange
      };
    });

    const color = getAssetColor(asset.assetType, index);
    let labelText = `${asset.symbol}`;
    
    if (!isMobile) {
      labelText += ` (${asset.name.length > 15 ? asset.name.substring(0, 15) + '...' : asset.name})`;
    }

    return {
      label: labelText,
      data: normalizedData.map(d => d.percentChange),
      borderColor: color,
      backgroundColor: 'transparent',
      borderWidth: 2,
      tension: 0.4,
      pointRadius: 0,
      pointHoverRadius: 4,
    };
  };

  // Filter datasets to only include valid ones
  const datasets = comparisonAssets
    .map((asset, index) => getAssetDataset(asset, index))
    .filter(dataset => dataset !== null);

  // Get the labels (dates) from the first available dataset
  const firstDataset = comparisonAssets.find(asset => 
    asset && asset.timeframeData && asset.timeframeData[timeframe]
  );

  const labels = firstDataset && firstDataset.timeframeData && firstDataset.timeframeData[timeframe]
    ? firstDataset.timeframeData[timeframe].map(d => {
        const date = new Date(d.time);
        if (timeframe === '1M') {
          return date.toLocaleDateString([], { month: 'short', day: 'numeric' });
        } else {
          return date.toLocaleDateString([], { month: 'short', day: 'numeric' });
        }
      })
    : [];

  // Chart data
  const chartData = {
    labels,
    datasets
  };

  // Chart options
  const chartOptions = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        position: 'top' as const,
        align: 'start' as const,
        labels: {
          boxWidth: 12,
          usePointStyle: true,
          pointStyle: 'circle',
        }
      },
      tooltip: {
        mode: 'index' as const,
        intersect: false,
        callbacks: {
          label: function(context: any) {
            return `${context.dataset.label}: ${context.parsed.y.toFixed(2)}%`;
          }
        }
      },
    },
    scales: {
      x: {
        grid: {
          display: false,
        },
        ticks: {
          maxTicksLimit: isMobile ? 5 : 10,
          color: 'hsl(var(--muted-foreground))',
        }
      },
      y: {
        grid: {
          color: 'rgba(0, 0, 0, 0.05)',
        },
        title: {
          display: true,
          text: 'Percent Change (%)',
          color: 'hsl(var(--muted-foreground))',
        },
        ticks: {
          callback: function(value: any) {
            return value.toFixed(1) + '%';
          },
          color: 'hsl(var(--muted-foreground))',
        },
      }
    },
    interaction: {
      intersect: false,
      mode: 'index' as const,
    },
  };

  // Asset type badge style adjustments for proper contrast
  const getAssetTypeBadgeStyle = (type: string) => {
    switch (type) {
      case 'stock':
        return { borderColor: '#4299E1', color: '#4299E1' };
      case 'bond':
        return { borderColor: '#805AD5', color: '#805AD5' };
      case 'commodity':
        return { borderColor: '#F6E05E', color: '#7b6015' };
      case 'etf':
        return { borderColor: '#68D391', color: '#2f8c53' };
      case 'mutual-fund':
        return { borderColor: '#F687B3', color: '#b44278' };
      default:
        return {};
    }
  };

  // Format asset type name
  const formatAssetType = (type: string) => {
    switch (type) {
      case 'all': return 'All Types';
      case 'stock': return 'Stocks';
      case 'bond': return 'Bonds';
      case 'commodity': return 'Commodities';
      case 'etf': return 'ETFs';
      case 'mutual-fund': return 'Mutual Funds';
      default: return type.charAt(0).toUpperCase() + type.slice(1).replace('-', ' ');
    }
  };

  return (
    <Card className="shadow-md">
      <CardHeader>
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div>
            <CardTitle>Asset Performance Comparison</CardTitle>
            <CardDescription className="mt-1">
              Compare performance of different assets over time
            </CardDescription>
          </div>
          <div className="flex flex-col sm:flex-row w-full md:w-auto gap-2">
            <Select value={localAssetType} onValueChange={handleAssetTypeChange}>
              <SelectTrigger className="w-full sm:w-[180px]">
                <SelectValue placeholder="Select asset type" />
              </SelectTrigger>
              <SelectContent>
                {assetTypes.map(type => (
                  <SelectItem key={type} value={type} className={type === 'etf' ? 'text-etf' : ''}>
                    {formatAssetType(type)}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Tabs value={timeframe} onValueChange={(v) => setTimeframe(v as any)}>
              <TabsList>
                <TabsTrigger value="1M">1M</TabsTrigger>
                <TabsTrigger value="6M">6M</TabsTrigger>
                <TabsTrigger value="1Y">1Y</TabsTrigger>
              </TabsList>
            </Tabs>
          </div>
        </div>
        <div className="flex flex-wrap gap-2 mt-2">
          {comparisonAssets.map((asset, index) => (
            <Badge 
              key={asset.symbol}
              variant="outline" 
              style={getAssetTypeBadgeStyle(asset.assetType)}
              className={asset.assetType === 'etf' ? 'text-etf' : ''}
            >
              {asset.symbol} ({asset.assetType === 'etf' ? 'ETF' : formatAssetType(asset.assetType)})
            </Badge>
          ))}
        </div>
      </CardHeader>
      <CardContent>
        <div className="chart-container" style={{ height: '400px' }}>
          {datasets.length > 0 ? (
            <Line data={chartData} options={chartOptions} />
          ) : (
            <div className="h-full flex items-center justify-center text-muted-foreground">
              No comparison data available for the selected timeframe
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
};

export default ComparisonChart;