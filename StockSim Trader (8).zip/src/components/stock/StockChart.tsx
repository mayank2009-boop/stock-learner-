import React, { useState, useEffect, useCallback } from 'react';
import { useAssetStore } from '@/store/asset-store';
import { Line } from 'react-chartjs-2';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend,
  Filler
} from 'chart.js';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { AssetData } from '@/lib/stock-data';
import { RefreshCcw } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useIsMobile } from '@/hooks/use-mobile';
import { Badge } from '@/components/ui/badge';
import { useToast } from '@/hooks/use-toast';

// Register Chart.js components
ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend,
  Filler
);

interface AssetChartProps {
  assetData: AssetData;
  refreshData?: () => void;
  chartId?: string; // Add unique ID for each chart instance
}

const AssetChart: React.FC<AssetChartProps> = ({ assetData, refreshData, chartId = "asset-chart" }) => {
  // Get timeframe from global store to keep charts in sync
  const { timeframe, setTimeframe } = useAssetStore();
  const isMobile = useIsMobile();
  const { toast } = useToast();
  const chartIdRef = React.useRef(`${chartId}-${assetData.symbol}`);

  // Get the appropriate data for the selected timeframe
  const getTimeframeData = useCallback(() => {
    // First, check if timeframeData exists and has the current timeframe
    if (assetData.timeframeData && assetData.timeframeData[timeframe]) {
      return assetData.timeframeData[timeframe];
    }
    return assetData.data; // Fallback to default data
  }, [assetData, timeframe]);

  // Format chart data
  const chartData = {
    labels: getTimeframeData().map(d => {
      const date = new Date(d.time);
      // Format label based on timeframe
      switch (timeframe) {
        case '1D':
          return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
        case '1W':
          return date.toLocaleDateString([], { weekday: 'short', month: 'numeric', day: 'numeric' });
        case '1M':
        case '6M':
        case '1Y':
          return date.toLocaleDateString([], { month: 'short', day: 'numeric' });
        default:
          return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
      }
    }),
    datasets: [
      {
        label: assetData.symbol,
        data: getTimeframeData().map(d => d.price),
        borderColor: assetData.change >= 0 ? 'hsl(var(--profit))' : 'hsl(var(--loss))',
        backgroundColor: assetData.change >= 0 
          ? 'rgba(39, 174, 96, 0.1)' 
          : 'rgba(231, 76, 60, 0.1)',
        borderWidth: 2,
        tension: 0.4,
        fill: true,
        pointRadius: getTimeframeData().length < 8 ? 3 : 0,
        pointHoverRadius: 5,
      }
    ]
  };

  // Chart options
  const chartOptions = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        display: false,
      },
      tooltip: {
        mode: 'index' as const,
        intersect: false,
        callbacks: {
          label: function(context: any) {
            return `$${context.parsed.y.toFixed(2)}`;
          },
          title: function(context: any) {
            const date = new Date(getTimeframeData()[context[0].dataIndex].time);
            switch (timeframe) {
              case '1D':
                return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
              case '1W':
              case '1M':
                return date.toLocaleDateString([], { weekday: 'short', month: 'short', day: 'numeric' });
              case '6M':
              case '1Y':
                return date.toLocaleDateString([], { year: 'numeric', month: 'short', day: 'numeric' });
              default:
                return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
            }
          }
        }
      },
    },
    scales: {
      x: {
        grid: {
          display: false,
        },
        ticks: {
          maxTicksLimit: isMobile ? 4 : 8,
          color: 'hsl(var(--muted-foreground))',
          font: {
            size: isMobile ? 9 : 11,
          }
        }
      },
      y: {
        grid: {
          color: 'rgba(0, 0, 0, 0.05)',
        },
        ticks: {
          callback: function(value: any) {
            return '$' + value.toFixed(2);
          },
          color: 'hsl(var(--muted-foreground))',
          font: {
            size: isMobile ? 9 : 11,
          },
          maxTicksLimit: isMobile ? 5 : 8,
        },
      }
    },
    interaction: {
      intersect: false,
      mode: 'index' as const,
    },
    elements: {
      point: {
        radius: 0,
        hitRadius: 10,
        hoverRadius: 5,
      },
    },
  };

  // Get the appropriate asset type display name with ETF in uppercase
  const getAssetTypeDisplay = () => {
    switch (assetData.assetType) {
      case 'stock':
        return 'Stock';
      case 'bond':
        return 'Bond';
      case 'commodity':
        return 'Commodity';
      case 'etf':
        return 'ETF';
      case 'mutual-fund':
        return 'Mutual Fund';
      default:
        return '';
    }
  };

  // Update chartIdRef when assetData changes
  useEffect(() => {
    chartIdRef.current = `${chartId}-${assetData.symbol}`;
  }, [chartId, assetData.symbol]);

  // Auto-refresh every 30 seconds
  useEffect(() => {
    const interval = setInterval(() => {
      if (refreshData) refreshData();
    }, 30000); // 30 seconds

    return () => clearInterval(interval);
  }, [refreshData]);

  // Handle manual refresh
  const handleRefresh = () => {
    if (refreshData) {
      refreshData();
      toast({
        title: "Chart Updated",
        description: `${assetData.symbol} data has been refreshed.`
      });
    }
  };

  // Handle timeframe change - updates the central store
  const handleTimeframeChange = (value: string) => {
    setTimeframe(value as '1D' | '1W' | '1M' | '6M' | '1Y');
  };

  return (
    <Card className="shadow-md" id={chartIdRef.current}>
      <CardHeader className="pb-2 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <CardTitle className="text-xl flex flex-wrap items-center gap-2">
            {assetData.symbol} 
            <Badge 
              variant="outline" 
              className={`ml-2 ${assetData.assetType === 'etf' ? 'text-etf' : ''}`}
            >
              {getAssetTypeDisplay()}
            </Badge>
          </CardTitle>
          <div className="text-sm font-normal text-muted-foreground line-clamp-1 mt-1">
            {assetData.name}
          </div>
          <div className="flex items-center gap-3 mt-1">
            <span className="text-lg font-semibold">${assetData.price.toFixed(2)}</span>
            <span className={assetData.change >= 0 ? "text-profit" : "text-loss"}>
              {assetData.change >= 0 ? "+" : ""}{assetData.change.toFixed(2)} ({assetData.change >= 0 ? "+" : ""}{assetData.changePercent.toFixed(2)}%)
            </span>
          </div>
        </div>
        <div className="flex flex-col sm:flex-row items-start sm:items-center gap-2 w-full sm:w-auto">
          <Tabs value={timeframe} onValueChange={handleTimeframeChange} className="w-full sm:w-auto">
            <TabsList className="grid grid-cols-5 w-full sm:w-auto">
              <TabsTrigger value="1D" className="px-2 sm:px-3 text-xs sm:text-sm">1D</TabsTrigger>
              <TabsTrigger value="1W" className="px-2 sm:px-3 text-xs sm:text-sm">1W</TabsTrigger>
              <TabsTrigger value="1M" className="px-2 sm:px-3 text-xs sm:text-sm">1M</TabsTrigger>
              <TabsTrigger value="6M" className="px-2 sm:px-3 text-xs sm:text-sm">6M</TabsTrigger>
              <TabsTrigger value="1Y" className="px-2 sm:px-3 text-xs sm:text-sm">1Y</TabsTrigger>
            </TabsList>
          </Tabs>
          {refreshData && (
            <Button 
              variant="outline" 
              size="icon" 
              onClick={handleRefresh} 
              title="Refresh Data"
              className="sm:ml-auto"
              aria-label="Refresh chart data"
            >
              <RefreshCcw className="h-4 w-4" />
            </Button>
          )}
        </div>
      </CardHeader>
      <CardContent>
        <div className="chart-responsive">
          <Line data={chartData} options={chartOptions} />
        </div>
      </CardContent>
    </Card>
  );
};

export default AssetChart;