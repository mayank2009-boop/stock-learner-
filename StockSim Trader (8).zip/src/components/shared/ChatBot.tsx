import React, { useState, useRef, useEffect } from 'react';
import { MessageCircle, X, MinusIcon, Send, ArrowUpIcon, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Tooltip, TooltipContent, TooltipTrigger } from '@/components/ui/tooltip';
import { Badge } from '@/components/ui/badge';
import { Textarea } from '@/components/ui/textarea';

interface Message {
  id: string;
  text: string;
  isUser: boolean;
  timestamp: Date;
}

const predefinedResponses: Record<string, string> = {
  "how to use simulator": "To use the Trading Simulator, navigate to the 'Simulate' tab. Select an asset from the 'Available Assets' panel, view its chart, then use the Trade Panel to buy or sell. You'll see your portfolio value and holdings update in real-time.",
  "what assets are available": "The platform offers various asset types: stocks (like AAPL, MSFT), ETFs (like SPY, QQQ), bonds (like BND), commodities (gold, silver), and mutual funds. Each has different risk profiles and performance characteristics.",
  "how to track portfolio": "Your portfolio is automatically tracked in the 'Simulate' section. The Portfolio Summary shows your total value, asset allocation, and performance. The Portfolio Holdings table displays all your positions with current values and profit/loss information.",
  "what is etf": "ETFs (Exchange-Traded Funds) are investment funds traded on stock exchanges that hold assets such as stocks, bonds, or commodities. They typically track an index and offer diversification with lower fees than mutual funds. They trade like stocks throughout the day.",
  "help": "I can help you with questions about trading concepts, using the simulator, understanding different asset types, portfolio tracking, and navigating the platform. Try asking about specific features or investment topics."
};

const ChatBot: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [isMinimized, setIsMinimized] = useState(false);
  const [messages, setMessages] = useState<Message[]>([
    {
      id: "welcome",
      text: "👋 Hi there! I'm your StockLearn assistant. How can I help you today? You can ask about trading concepts, the simulator, portfolio tracking, or asset types.",
      isUser: false,
      timestamp: new Date()
    }
  ]);
  const [inputValue, setInputValue] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLTextAreaElement>(null);

  useEffect(() => {
    if (messagesEndRef.current) {
      messagesEndRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [messages]);
  
  // Focus input when chat is opened
  useEffect(() => {
    if (isOpen && !isMinimized && inputRef.current) {
      inputRef.current.focus();
    }
  }, [isOpen, isMinimized]);

  const toggleChat = () => {
    setIsOpen(!isOpen);
    setIsMinimized(false);
  };

  const minimizeChat = () => {
    setIsMinimized(!isMinimized);
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    setInputValue(e.target.value);
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  const getResponse = (query: string): string => {
    const lowerCaseQuery = query.toLowerCase();
    
    // Check predefined responses
    for (const [key, response] of Object.entries(predefinedResponses)) {
      if (lowerCaseQuery.includes(key)) {
        return response;
      }
    }
    
    // Common fallbacks based on categories
    if (lowerCaseQuery.includes('stock') || lowerCaseQuery.includes('share')) {
      return "Stocks represent ownership in a company. When you buy a stock, you become a shareholder, entitled to a portion of the company's profits and assets. Stock prices fluctuate based on market conditions and company performance.";
    }
    
    if (lowerCaseQuery.includes('bond')) {
      return "Bonds are debt securities where investors lend money to an entity (like a government or corporation) for a defined period at a fixed or variable interest rate. They're generally considered lower risk than stocks but offer lower potential returns.";
    }
    
    if (lowerCaseQuery.includes('mutual fund')) {
      return "Mutual funds pool money from many investors to purchase a diversified portfolio of securities, managed by professional fund managers. They're priced once daily after market close, unlike ETFs which trade throughout the day.";
    }
    
    if (lowerCaseQuery.includes('commodity') || lowerCaseQuery.includes('gold') || lowerCaseQuery.includes('silver')) {
      return "Commodities are physical goods like gold, silver, oil, or agricultural products. They can serve as a hedge against inflation and provide portfolio diversification with typically low correlation to stocks and bonds.";
    }
    
    if (lowerCaseQuery.includes('learn') || lowerCaseQuery.includes('course')) {
      return "The Learn section provides educational resources on various trading concepts, asset types, and investment strategies. Each topic includes detailed content and quizzes to test your knowledge. Start with the basics and progressively move to more advanced topics.";
    }
    
    if (lowerCaseQuery.includes('quiz') || lowerCaseQuery.includes('test')) {
      return "Quizzes help reinforce your learning. Navigate to the Quiz section or select the 'Start Quiz' option within any learning topic to test your knowledge. Each quiz provides instant feedback and explanations for correct answers.";
    }

    // Default response if no patterns match
    return "I don't have specific information about that yet. For detailed assistance, consider checking the educational resources in the Learn section or trying the simulator for hands-on experience.";
  };

  const handleSendMessage = () => {
    if (!inputValue.trim()) return;
    
    const userMessage: Message = {
      id: `user-${Date.now()}`,
      text: inputValue,
      isUser: true,
      timestamp: new Date()
    };
    
    setMessages(prev => [...prev, userMessage]);
    setInputValue('');
    setIsTyping(true);
    
    // Simulate typing delay for a more natural conversation feel
    setTimeout(() => {
      const botResponse: Message = {
        id: `bot-${Date.now()}`,
        text: getResponse(inputValue),
        isUser: false,
        timestamp: new Date()
      };
      
      setMessages(prev => [...prev, botResponse]);
      setIsTyping(false);
    }, 800 + Math.random() * 800); // Random delay between 800-1600ms
  };

  const suggestionTopics = [
    "How to use simulator", 
    "What assets are available", 
    "How to track portfolio", 
    "What is ETF"
  ];

  return (
    <>
      {/* Chat button */}
      <Button
        onClick={toggleChat}
        className={`fixed bottom-6 right-6 h-14 w-14 rounded-full shadow-lg z-50 flex items-center justify-center ${
          isOpen ? 'bg-primary hover:bg-primary/90' : 'bg-primary hover:bg-primary/90'
        }`}
        size="icon"
        aria-label="Open AI assistant"
      >
        {isOpen ? (
          <X className="h-6 w-6" />
        ) : (
          <>
            <MessageCircle className="h-6 w-6" />
            <span className="sr-only">Open AI assistant</span>
          </>
        )}
      </Button>

      {/* Chat window */}
      {isOpen && (
        <Card className={`fixed bottom-24 right-6 w-[90%] sm:w-[400px] max-w-[400px] shadow-xl z-50 border border-border/50 rounded-xl transition-all duration-200 ease-in-out overflow-hidden ${
          isMinimized ? 'h-[60px]' : 'h-[500px] max-h-[80vh]'
        }`}>
          <CardHeader className="p-3 border-b flex flex-row items-center justify-between bg-muted/30">
            <div className="flex items-center">
              <MessageCircle className="h-5 w-5 mr-2" />
              <CardTitle className="text-base">StockLearn Assistant</CardTitle>
            </div>
            <div className="flex items-center gap-1">
              <Button 
                variant="ghost" 
                size="icon" 
                className="h-8 w-8"
                onClick={minimizeChat}
                aria-label={isMinimized ? "Expand chat" : "Minimize chat"}
              >
                <MinusIcon className="h-4 w-4" />
              </Button>
              <Button 
                variant="ghost" 
                size="icon" 
                className="h-8 w-8"
                onClick={toggleChat}
                aria-label="Close chat"
              >
                <X className="h-4 w-4" />
              </Button>
            </div>
          </CardHeader>
          
          {!isMinimized && (
            <>
              <CardContent className="p-0 flex flex-col h-[calc(500px-120px)] max-h-[calc(80vh-120px)]">
                <div className="flex-1 overflow-y-auto p-4 space-y-4">
                  {messages.map((message) => (
                    <div
                      key={message.id}
                      className={`flex ${message.isUser ? 'justify-end' : 'justify-start'}`}
                    >
                      <div
                        className={`max-w-[80%] px-4 py-2 rounded-lg ${
                          message.isUser
                            ? 'bg-primary text-primary-foreground rounded-br-none'
                            : 'bg-muted text-foreground rounded-bl-none'
                        }`}
                      >
                        <p className="text-sm">{message.text}</p>
                        <p className="text-[10px] mt-1 opacity-70">
                          {message.timestamp.toLocaleTimeString([], { 
                            hour: '2-digit', 
                            minute: '2-digit' 
                          })}
                        </p>
                      </div>
                    </div>
                  ))}
                  
                  {isTyping && (
                    <div className="flex justify-start">
                      <div className="max-w-[80%] px-4 py-2 rounded-lg bg-muted text-foreground rounded-bl-none">
                        <div className="flex items-center gap-1">
                          <div className="w-2 h-2 rounded-full bg-primary animate-pulse"></div>
                          <div className="w-2 h-2 rounded-full bg-primary animate-pulse delay-75"></div>
                          <div className="w-2 h-2 rounded-full bg-primary animate-pulse delay-150"></div>
                        </div>
                      </div>
                    </div>
                  )}
                  
                  <div ref={messagesEndRef} />
                </div>
                
                {messages.length === 1 && (
                  <div className="p-4 border-t">
                    <p className="text-xs text-muted-foreground mb-2">Suggested topics:</p>
                    <div className="flex flex-wrap gap-2">
                      {suggestionTopics.map((topic) => (
                        <Badge 
                          key={topic}
                          variant="outline"
                          className="cursor-pointer hover:bg-muted transition-colors"
                          onClick={() => {
                            setInputValue(topic);
                            if (inputRef.current) inputRef.current.focus();
                          }}
                        >
                          {topic}
                        </Badge>
                      ))}
                    </div>
                  </div>
                )}
              </CardContent>
              
              <CardFooter className="p-3 border-t">
                <div className="flex w-full gap-2">
                  <Textarea
                    ref={inputRef}
                    placeholder="Type your message..."
                    value={inputValue}
                    onChange={handleInputChange}
                    onKeyDown={handleKeyDown}
                    className="min-h-[44px] max-h-[120px]"
                    rows={1}
                  />
                  <Tooltip>
                    <TooltipTrigger asChild>
                      <Button
                        className="shrink-0"
                        size="icon"
                        onClick={handleSendMessage}
                        disabled={!inputValue.trim() || isTyping}
                        aria-label="Send message"
                      >
                        <Send className="h-4 w-4" />
                      </Button>
                    </TooltipTrigger>
                    <TooltipContent side="left">Send message</TooltipContent>
                  </Tooltip>
                </div>
                <div className="w-full text-center mt-2">
                  <p className="text-[10px] text-muted-foreground">
                    Need more help? Contact <a href="#" className="underline hover:text-primary">support@stocklearn.com</a>
                  </p>
                </div>
              </CardFooter>
            </>
          )}
        </Card>
      )}
    </>
  );
};

export default ChatBot;