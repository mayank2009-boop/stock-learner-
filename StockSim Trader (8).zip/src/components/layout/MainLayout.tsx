import React from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { Moon, Sun, BarChart2, GraduationCap, TrendingUp, Home, Menu, X, HelpCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Sheet, SheetContent, SheetTrigger } from '@/components/ui/sheet';
import { useToast } from '@/hooks/use-toast';
import { useIsMobile } from '@/hooks/use-mobile';
import { Tooltip, TooltipContent, TooltipTrigger, TooltipProvider } from '@/components/ui/tooltip';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import ChatBot from '@/components/shared/ChatBot';

interface MainLayoutProps {
  children: React.ReactNode;
  setActiveTab?: (tab: string) => void;
  activeTab?: string;
}

const MainLayout: React.FC<MainLayoutProps> = ({ children, setActiveTab, activeTab }) => {
  const [darkMode, setDarkMode] = React.useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = React.useState(false);
  const navigate = useNavigate();
  const location = useLocation();
  const { toast } = useToast();
  const isMobile = useIsMobile();

  React.useEffect(() => {
    // Check if user prefers dark mode
    if (window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches) {
      setDarkMode(true);
      document.documentElement.classList.add('dark');
    }
  }, []);

  const toggleDarkMode = () => {
    setDarkMode(!darkMode);
    if (darkMode) {
      document.documentElement.classList.remove('dark');
    } else {
      document.documentElement.classList.add('dark');
    }
  };

  // Modified navItems to work with tabs and reordered to place Market Insights before Quiz
  const navItems = [
    { name: 'Home', icon: Home, path: '/', tabId: 'home' },
    { name: 'Learn', icon: GraduationCap, path: '/learn', tabId: 'learn' },
    { name: 'Simulate', icon: TrendingUp, path: '/simulate', tabId: 'simulate' },
    { name: 'Market Insights', icon: BarChart2, path: '/market-insights', tabId: 'insights' },
    { name: 'Quiz', icon: HelpCircle, path: '/quiz', tabId: 'quiz' },
  ];

  const handleNavClick = (path: string, tabId: string) => {
    // If we're already on the homepage, just switch tabs
    if (location.pathname === '/') {
      if (setActiveTab) {
        setActiveTab(tabId);
        
        // Smooth scroll to section if it exists
        setTimeout(() => {
          const section = document.getElementById(tabId);
          if (section) {
            section.scrollIntoView({ behavior: 'smooth' });
          }
        }, 100);
      }
    } else {
      // Navigate to homepage with the specific tab
      navigate('/', { state: { activeTab: tabId } });
    }
    
    // Close mobile menu if open
    setMobileMenuOpen(false);
  };

  // Determine if a nav item is active based on the activeTab prop or path
  const isActive = (navItem: { path: string; tabId: string }) => {
    if (activeTab) {
      return navItem.tabId === activeTab;
    }
    return location.pathname === navItem.path;
  };

  return (
    <div className="min-h-screen flex flex-col">
      {/* Top Navigation Bar - Made sticky */}
      <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container flex h-14 items-center justify-between">
          <div className="flex items-center gap-2">
            {isMobile && (
              <Sheet open={mobileMenuOpen} onOpenChange={setMobileMenuOpen}>
                <SheetTrigger asChild>
                  <Button variant="ghost" size="icon" className="lg:hidden touch-target">
                    <Menu className="h-5 w-5" />
                    <span className="sr-only">Toggle menu</span>
                  </Button>
                </SheetTrigger>
                <SheetContent side="left" className="bg-background overflow-y-auto">
                  <div className="flex flex-col gap-6 pt-6">
                    <div className="flex items-center gap-2">
                      <BarChart2 className="h-6 w-6" />
                      <h2 className="text-xl font-bold">StockLearn</h2>
                    </div>
                    <nav className="flex flex-col gap-2">
                      {navItems.map((item) => (
                        <Button 
                          key={item.path}
                          variant={isActive(item) ? "default" : "ghost"}
                          className="justify-start touch-target"
                          onClick={() => handleNavClick(item.path, item.tabId)}
                        >
                          <item.icon className="mr-2 h-5 w-5" />
                          {item.name}
                        </Button>
                      ))}
                    </nav>
                  </div>
                </SheetContent>
              </Sheet>
            )}
            <Button 
              variant="ghost" 
              className="p-0 h-auto"
              onClick={() => handleNavClick('/', 'home')}
            >
              <BarChart2 className="h-6 w-6 stocklearn-logo" />
              <h1 className="text-xl font-bold hidden sm:inline-block ml-2">StockLearn</h1>
            </Button>
          </div>

          {/* Desktop Navigation */}
          <nav className="hidden lg:flex items-center gap-1">
            <TooltipProvider>
              {navItems.map((item) => (
                <Tooltip key={item.path}>
                  <TooltipTrigger asChild>
                    <Button 
                      variant={isActive(item) ? "default" : "ghost"}
                      onClick={() => handleNavClick(item.path, item.tabId)}
                      className="flex items-center gap-2"
                    >
                      <item.icon className="h-4 w-4" />
                      {item.name}
                    </Button>
                  </TooltipTrigger>
                  <TooltipContent>{item.name}</TooltipContent>
                </Tooltip>
              ))}
            </TooltipProvider>
          </nav>

          {/* Mobile Navigation Tabs */}
          <nav className="lg:hidden flex overflow-x-auto hide-scrollbar">
            {navItems.slice(1, 5).map((item) => (
              <Button 
                key={item.path}
                variant={isActive(item) ? "secondary" : "ghost"}
                size="sm"
                onClick={() => handleNavClick(item.path, item.tabId)}
                className="px-2 min-w-[auto] touch-target"
              >
                <item.icon className="h-4 w-4" />
                <span className="sr-only">{item.name}</span>
              </Button>
            ))}
          </nav>

          <div className="flex items-center gap-2">
            <div className="flex items-center space-x-2">
              <Label htmlFor="dark-mode" className="sr-only">Dark Mode</Label>
              <Switch
                id="dark-mode"
                checked={darkMode}
                onCheckedChange={toggleDarkMode}
                aria-label="Toggle dark mode"
              />
              {darkMode ? (
                <Moon className="h-4 w-4" />
              ) : (
                <Sun className="h-4 w-4" />
              )}
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 w-full">
        {children}
      </main>

      {/* Footer */}
      <footer className="border-t py-6 md:py-0 mt-8">
        <div className="container flex flex-col items-center justify-between gap-4 md:h-16 md:flex-row">
          <p className="text-center text-sm leading-loose text-muted-foreground md:text-left">
            &copy; {new Date().getFullYear()} StockLearn. Educational purposes only.
          </p>
        </div>
      </footer>

      {/* ChatBot Component */}
      <ChatBot />
    </div>
  );
};

export default MainLayout;