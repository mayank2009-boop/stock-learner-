import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Wallet, TrendingUp, Banknote, PieChart, ArrowUp, ArrowDown } from 'lucide-react';
import { AssetData } from '@/lib/stock-data';

interface PortfolioSummaryProps {
  cash: number;
  assetValue: number;
  totalValue: number;
  assetAllocation?: {
    type: string;
    value: number;
  }[];
}

const PortfolioSummary: React.FC<PortfolioSummaryProps> = ({
  cash,
  assetValue,
  totalValue,
  assetAllocation = []
}) => {
  // Calculate initial investment (assuming it was $10,000)
  const initialInvestment = 10000;
  const totalReturn = totalValue - initialInvestment;
  const totalReturnPercent = (totalReturn / initialInvestment) * 100;
  const isPositive = totalReturn >= 0;
  
  // Format currency
  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 2,
      maximumFractionDigits: 2
    }).format(value);
  };

  // Get a color for the asset type
  const getAssetTypeColor = (type: string) => {
    switch (type) {
      case 'stock':
        return '#4299E1'; // Blue
      case 'bond':
        return '#805AD5'; // Purple
      case 'commodity':
        return '#F6E05E'; // Yellow
      case 'etf':
        return '#68D391'; // Green
      case 'mutual-fund':
        return '#F687B3'; // Pink
      default:
        return '#CBD5E0'; // Gray
    }
  };

  // Get asset type display name
  const getAssetTypeDisplay = (type: string) => {
    switch (type) {
      case 'stock':
        return 'Stocks';
      case 'bond':
        return 'Bonds';
      case 'commodity':
        return 'Commodities';
      case 'etf':
        return 'ETFs';
      case 'mutual-fund':
        return 'Mutual Funds';
      default:
        return type.charAt(0).toUpperCase() + type.slice(1) + 's';
    }
  };

  return (
    <Card className="shadow-md">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Wallet className="h-5 w-5" /> 
          Portfolio Summary
        </CardTitle>
        <CardDescription>
          Your virtual trading account
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="flex items-center gap-4 p-4 rounded-lg bg-secondary">
            <div className="p-2 rounded-full bg-primary/10">
              <Banknote className="h-6 w-6 text-primary" />
            </div>
            <div>
              <p className="text-sm font-medium text-muted-foreground">Available Cash</p>
              <p className="text-xl font-bold">{formatCurrency(cash)}</p>
            </div>
          </div>
          
          <div className="flex items-center gap-4 p-4 rounded-lg bg-secondary">
            <div className="p-2 rounded-full bg-primary/10">
              <PieChart className="h-6 w-6 text-primary" />
            </div>
            <div>
              <p className="text-sm font-medium text-muted-foreground">Asset Value</p>
              <p className="text-xl font-bold">{formatCurrency(assetValue)}</p>
            </div>
          </div>

          <div className="p-4 rounded-lg bg-primary text-primary-foreground md:col-span-2">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between">
              <div className="flex items-center gap-4">
                <div className="p-2 rounded-full bg-primary-foreground/20">
                  <TrendingUp className="h-6 w-6 text-primary-foreground" />
                </div>
                <div>
                  <p className="text-sm font-medium text-primary-foreground/80">Total Portfolio Value</p>
                  <div className="flex items-center flex-wrap gap-2 mt-0.5">
                    <p className="text-xl font-bold">{formatCurrency(totalValue)}</p>
                    {/* Enhanced portfolio performance display with proper alignment */}
                    <div 
                      className={`portfolio-performance-indicator inline-flex items-center ${isPositive ? 'portfolio-performance-positive' : 'portfolio-performance-negative'}`}
                      role="status"
                      aria-label={`Portfolio ${isPositive ? 'gain' : 'loss'} of ${Math.abs(totalReturnPercent).toFixed(2)}%`}
                    >
                      {isPositive ? (
                        <ArrowUp className="h-5 w-5 flex-shrink-0 performance-arrow-icon" aria-hidden="true" />
                      ) : (
                        <ArrowDown className="h-5 w-5 flex-shrink-0 performance-arrow-icon" aria-hidden="true" />
                      )}
                      <span>{isPositive ? '+' : ''}{totalReturnPercent.toFixed(2)}%</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {assetAllocation.length > 0 && (
            <div className="p-4 rounded-lg bg-secondary md:col-span-2 mt-2">
              <h4 className="text-sm font-medium mb-3">Asset Allocation</h4>
              <div className="flex gap-1 h-4 mb-3 rounded-full overflow-hidden">
                {assetAllocation.map((item, idx) => (
                  <div 
                    key={idx}
                    style={{ 
                      width: `${(item.value / assetValue) * 100}%`,
                      backgroundColor: getAssetTypeColor(item.type)
                    }}
                    className="h-full first:rounded-l-full last:rounded-r-full"
                  />
                ))}
              </div>
              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-2">
                {assetAllocation.map((item, idx) => (
                  <div key={idx} className="flex items-center gap-2">
                    <div 
                      className="h-3 w-3 rounded-full flex-shrink-0" 
                      style={{ backgroundColor: getAssetTypeColor(item.type) }}
                    />
                    <span className="text-xs text-muted-foreground whitespace-nowrap overflow-hidden text-ellipsis">
                      {getAssetTypeDisplay(item.type)}: {((item.value / assetValue) * 100).toFixed(1)}%
                    </span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
};

export default PortfolioSummary;