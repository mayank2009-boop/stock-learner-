import React from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Tabs, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  BarChart2,
  Landmark,
  CircleDollarSign,
  LineChart,
  Wallet
} from 'lucide-react';

interface AssetCategorySelectorProps {
  selectedCategory: string;
  onCategoryChange: (category: string) => void;
}

const AssetCategorySelector: React.FC<AssetCategorySelectorProps> = ({ 
  selectedCategory, 
  onCategoryChange 
}) => {
  return (
    <Card className="shadow-sm">
      <CardContent className="p-2">
        <Tabs 
          value={selectedCategory} 
          onValueChange={onCategoryChange}
          className="w-full asset-category-tabs"
        >
          <TabsList className="grid grid-cols-5 w-full">
            <TabsTrigger 
              value="all" 
              className="flex items-center justify-center gap-1.5 asset-category-tab"
            >
              <Wallet className="h-4 w-4 flex-shrink-0" />
              <span className="hidden xs:inline truncate">All</span>
            </TabsTrigger>
            <TabsTrigger 
              value="stock" 
              className="flex items-center justify-center gap-1.5 asset-category-tab"
            >
              <BarChart2 className="h-4 w-4 flex-shrink-0" />
              <span className="hidden xs:inline truncate">Stocks</span>
            </TabsTrigger>
            <TabsTrigger 
              value="bond" 
              className="flex items-center justify-center gap-1.5 asset-category-tab"
            >
              <Landmark className="h-4 w-4 flex-shrink-0" />
              <span className="hidden xs:inline truncate">Bonds</span>
            </TabsTrigger>
            <TabsTrigger 
              value="commodity" 
              className="flex items-center justify-center gap-1.5 asset-category-tab"
            >
              <CircleDollarSign className="h-4 w-4 flex-shrink-0" />
              <span className="hidden xs:inline truncate">Commodities</span>
            </TabsTrigger>
            <TabsTrigger 
              value="etf-mutual" 
              className="flex items-center justify-center gap-1.5 asset-category-tab"
            >
              <LineChart className="h-4 w-4 flex-shrink-0" />
              <span className="hidden xs:inline truncate">ETFs & Funds</span>
            </TabsTrigger>
          </TabsList>
        </Tabs>
      </CardContent>
    </Card>
  );
};

export default AssetCategorySelector;