import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { AssetData } from '@/lib/stock-data';
import { Briefcase, TrendingUp, TrendingDown, Filter } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuCheckboxItem, 
  DropdownMenuTrigger 
} from '@/components/ui/dropdown-menu';
import { Button } from '@/components/ui/button';

interface Position {
  symbol: string;
  shares: number;
  avgPrice: number;
  assetType?: 'stock' | 'bond' | 'commodity' | 'etf' | 'mutual-fund';
}

interface PortfolioHoldingsProps {
  positions: Position[];
  marketData: AssetData[];
  onSelectAsset?: (asset: AssetData) => void;
}

const PortfolioHoldings: React.FC<PortfolioHoldingsProps> = ({
  positions,
  marketData,
  onSelectAsset
}) => {
  // Filter state
  const [assetTypeFilter, setAssetTypeFilter] = useState<string[]>([]);
  
  // Combine positions with market data
  const holdingsWithData = positions.map(position => {
    const assetData = marketData.find(s => s.symbol === position.symbol);
    const currentPrice = assetData ? assetData.price : 0;
    const value = position.shares * currentPrice;
    const pnl = position.shares * (currentPrice - position.avgPrice);
    const pnlPercent = ((currentPrice - position.avgPrice) / position.avgPrice) * 100;

    return {
      ...position,
      currentPrice,
      value,
      pnl,
      pnlPercent,
      assetData,
      assetType: assetData?.assetType || position.assetType || 'stock',
    };
  });

  // Apply filters
  const filteredHoldings = holdingsWithData.filter(holding => 
    assetTypeFilter.length === 0 || assetTypeFilter.includes(holding.assetType)
  );

  // Format currency
  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 2,
      maximumFractionDigits: 2
    }).format(value);
  };

  // Get asset type display name with ETF in uppercase
  const getAssetTypeDisplay = (type: string) => {
    switch (type) {
      case 'stock':
        return 'Stock';
      case 'bond':
        return 'Bond';
      case 'commodity':
        return 'Commodity';
      case 'etf':
        return 'ETF'; // Explicitly uppercase
      case 'mutual-fund':
        return 'Fund';
      default:
        return type.charAt(0).toUpperCase() + type.slice(1);
    }
  };

  // Get a color for the asset type badge
  const getAssetTypeColor = (type: string) => {
    switch (type) {
      case 'stock':
        return 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-300';
      case 'bond':
        return 'bg-purple-100 text-purple-800 dark:bg-purple-900 dark:text-purple-300';
      case 'commodity':
        return 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-300';
      case 'etf':
        return 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300 text-etf'; // Added text-etf class
      case 'mutual-fund':
        return 'bg-pink-100 text-pink-800 dark:bg-pink-900 dark:text-pink-300';
      default:
        return 'bg-gray-100 text-gray-800 dark:bg-gray-800 dark:text-gray-300';
    }
  };

  // Get available asset types for filtering
  const availableAssetTypes = Array.from(
    new Set(holdingsWithData.map(h => h.assetType))
  ).filter(Boolean) as string[];

  // Toggle asset type filter
  const toggleAssetTypeFilter = (value: string) => {
    setAssetTypeFilter(current => 
      current.includes(value)
        ? current.filter(item => item !== value)
        : [...current, value]
    );
  };

  return (
    <Card className="shadow-md">
      <CardHeader>
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-2">
          <CardTitle className="flex items-center gap-2">
            <Briefcase className="h-5 w-5" />
            Portfolio Holdings
          </CardTitle>
          {availableAssetTypes.length > 1 && (
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="outline" size="sm" className="h-8 gap-1">
                  <Filter className="h-4 w-4" />
                  Filter
                  {assetTypeFilter.length > 0 && (
                    <Badge variant="secondary" className="ml-1 h-5 px-1.5">
                      {assetTypeFilter.length}
                    </Badge>
                  )}
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                {availableAssetTypes.map((type) => (
                  <DropdownMenuCheckboxItem
                    key={type}
                    checked={assetTypeFilter.includes(type)}
                    onCheckedChange={() => toggleAssetTypeFilter(type)}
                  >
                    {type === 'etf' ? 'ETF' : getAssetTypeDisplay(type)}
                  </DropdownMenuCheckboxItem>
                ))}
                {assetTypeFilter.length > 0 && (
                  <Button
                    variant="ghost"
                    size="sm"
                    className="w-full mt-2"
                    onClick={() => setAssetTypeFilter([])}
                  >
                    Clear Filters
                  </Button>
                )}
              </DropdownMenuContent>
            </DropdownMenu>
          )}
        </div>
        <CardDescription>
          Your current portfolio positions
        </CardDescription>
      </CardHeader>
      <CardContent>
        {positions.length === 0 ? (
          <div className="text-center py-6 text-muted-foreground">
            <p>You don't own any assets yet.</p>
            <p className="text-sm mt-1">Use the trade panel to make your first purchase.</p>
          </div>
        ) : filteredHoldings.length === 0 ? (
          <div className="text-center py-6 text-muted-foreground">
            <p>No holdings match your filter criteria.</p>
            <Button 
              variant="ghost" 
              size="sm" 
              onClick={() => setAssetTypeFilter([])}
              className="mt-2"
            >
              Clear Filters
            </Button>
          </div>
        ) : (
          <div className="responsive-table-wrapper">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Symbol</TableHead>
                  <TableHead className="hidden xs:table-cell">Type</TableHead>
                  <TableHead className="text-right">Units</TableHead>
                  <TableHead className="hidden sm:table-cell text-right">Avg Price</TableHead>
                  <TableHead className="text-right">Current</TableHead>
                  <TableHead className="hidden sm:table-cell text-right">Value</TableHead>
                  <TableHead className="text-right">P/L</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredHoldings.map((holding) => (
                  <TableRow
                    key={holding.symbol}
                    className={onSelectAsset && holding.assetData ? "cursor-pointer hover:bg-secondary" : ""}
                    onClick={() => {
                      if (onSelectAsset && holding.assetData) {
                        onSelectAsset(holding.assetData);
                      }
                    }}
                  >
                    <TableCell className="font-medium">{holding.symbol}</TableCell>
                    <TableCell className="hidden xs:table-cell">
                      <Badge 
                        variant="outline" 
                        className={`${getAssetTypeColor(holding.assetType)} text-xs whitespace-nowrap`}
                      >
                        {getAssetTypeDisplay(holding.assetType)}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-right">{holding.shares}</TableCell>
                    <TableCell className="hidden sm:table-cell text-right">{formatCurrency(holding.avgPrice)}</TableCell>
                    <TableCell className="text-right">{formatCurrency(holding.currentPrice)}</TableCell>
                    <TableCell className="hidden sm:table-cell text-right">{formatCurrency(holding.value)}</TableCell>
                    <TableCell className="text-right">
                      <div className="flex items-center justify-end gap-1">
                        {holding.pnl >= 0 ? (
                          <TrendingUp className="h-4 w-4 text-profit hidden sm:block" />
                        ) : (
                          <TrendingDown className="h-4 w-4 text-loss hidden sm:block" />
                        )}
                        <span className={holding.pnl >= 0 ? "text-profit" : "text-loss"}>
                          <span className="hidden sm:inline">{formatCurrency(holding.pnl)}</span>
                          <span>({holding.pnl >= 0 ? "+" : ""}{holding.pnlPercent.toFixed(2)}%)</span>
                        </span>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default PortfolioHoldings;