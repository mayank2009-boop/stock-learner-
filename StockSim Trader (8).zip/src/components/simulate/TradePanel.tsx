import React, { useState, useEffect } from 'react';
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
import { Input } from '@/components/ui/input';
import { AssetData, assetTypeTooltips } from '@/lib/stock-data';
import { ArrowRightLeft, HelpCircle, Info, Calculator } from 'lucide-react';
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import { useToast } from '@/hooks/use-toast';
import { Badge } from '@/components/ui/badge';

interface TradePanelProps {
  selectedAsset: AssetData;
  availableCash: number;
  onTrade: (type: 'buy' | 'sell', symbol: string, shares: number, price: number) => void;
  ownedShares: number;
}

const TradePanel: React.FC<TradePanelProps> = ({
  selectedAsset,
  availableCash,
  onTrade,
  ownedShares = 0,
}) => {
  const [tradeType, setTradeType] = useState<'buy' | 'sell'>('buy');
  const [shares, setShares] = useState('');
  const { toast } = useToast();
  const [maxPurchasableUnits, setMaxPurchasableUnits] = useState<number>(0);

  // Calculate maximum units that can be purchased with available cash
  useEffect(() => {
    if (selectedAsset && availableCash) {
      const maxUnits = Math.floor(availableCash / selectedAsset.price);
      setMaxPurchasableUnits(maxUnits);
    }
  }, [selectedAsset, availableCash]);

  const handleSharesChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;
    // Only allow numbers
    if (/^\d*$/.test(value)) {
      setShares(value);
    }
  };

  const calculateTotal = () => {
    const sharesNum = parseInt(shares) || 0;
    return sharesNum * selectedAsset.price;
  };

  const getUnitName = () => {
    switch(selectedAsset.assetType) {
      case 'bond':
        return 'bonds';
      case 'stock':
        return 'shares';
      case 'etf':
        return 'shares';
      case 'mutual-fund':
        return 'units';
      case 'commodity':
        return 'units';
      default:
        return 'units';
    }
  };

  const getAssetTypeColor = (type: string) => {
    switch (type) {
      case 'stock':
        return 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-300';
      case 'bond':
        return 'bg-purple-100 text-purple-800 dark:bg-purple-900 dark:text-purple-300';
      case 'commodity':
        return 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-300';
      case 'etf':
        return 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300 text-etf';
      case 'mutual-fund':
        return 'bg-pink-100 text-pink-800 dark:bg-pink-900 dark:text-pink-300';
      default:
        return 'bg-gray-100 text-gray-800 dark:bg-gray-800 dark:text-gray-300';
    }
  };

  const handleTrade = () => {
    const sharesNum = parseInt(shares);
    if (!sharesNum || sharesNum <= 0) {
      toast({
        title: "Invalid Quantity",
        description: `Please enter a valid number of ${getUnitName()}.`,
      });
      return;
    }

    if (tradeType === 'buy') {
      if (calculateTotal() > availableCash) {
        toast({
          title: "Insufficient Funds",
          description: "You don't have enough cash for this purchase.",
        });
        return;
      }

      onTrade('buy', selectedAsset.symbol, sharesNum, selectedAsset.price);
      toast({
        title: "Purchase Complete",
        description: `You bought ${sharesNum} ${getUnitName()} of ${selectedAsset.symbol}.`,
      });
    } else {
      if (sharesNum > ownedShares) {
        toast({
          title: "Insufficient Holdings",
          description: `You only own ${ownedShares} ${getUnitName()} of ${selectedAsset.symbol}.`,
        });
        return;
      }

      onTrade('sell', selectedAsset.symbol, sharesNum, selectedAsset.price);
      toast({
        title: "Sale Complete",
        description: `You sold ${sharesNum} ${getUnitName()} of ${selectedAsset.symbol}.`,
      });
    }

    setShares('');
  };

  // Format currency
  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 2,
      maximumFractionDigits: 2
    }).format(value);
  };

  // Get tooltip for asset type
  const getAssetTooltip = () => {
    return assetTypeTooltips[selectedAsset.assetType] || 'Learn about this asset type';
  };

  // Get display name for asset type
  const getAssetTypeDisplay = (type: string) => {
    switch (type) {
      case 'stock':
        return 'Stock';
      case 'bond':
        return 'Bond';
      case 'commodity':
        return 'Commodity';
      case 'etf':
        return 'ETF'; // Keep uppercase
      case 'mutual-fund':
        return 'Mutual Fund';
      default:
        return type.charAt(0).toUpperCase() + type.slice(1);
    }
  };

  const handleMaxUnits = () => {
    setShares(maxPurchasableUnits.toString());
  };

  return (
    <Card className="shadow-md">
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2">
            <ArrowRightLeft className="h-5 w-5" />
            <span className="hidden xs:inline">Trade</span>
            <Badge 
              variant="outline" 
              className={`ml-2 ${getAssetTypeColor(selectedAsset.assetType)}`}
            >
              {getAssetTypeDisplay(selectedAsset.assetType)}
            </Badge>
          </CardTitle>
        </div>
        <CardDescription className="flex flex-col xs:flex-row justify-between items-start xs:items-center gap-1">
          <span className="line-clamp-1">{selectedAsset.name} ({selectedAsset.symbol})</span>
          <TooltipProvider>
            <Tooltip>
              <TooltipTrigger className="flex items-center text-xs text-muted-foreground cursor-help">
                <Info className="h-3 w-3 mr-1" />
                <span>What is {selectedAsset.assetType === 'etf' ? 'an' : 'a'} {getAssetTypeDisplay(selectedAsset.assetType)}?</span>
              </TooltipTrigger>
              <TooltipContent side="left" className="w-80 max-w-[90vw]">
                <p>{getAssetTooltip()}</p>
              </TooltipContent>
            </Tooltip>
          </TooltipProvider>
        </CardDescription>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue="buy" value={tradeType} onValueChange={(v) => setTradeType(v as 'buy' | 'sell')}>
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="buy">Buy</TabsTrigger>
            <TabsTrigger value="sell">Sell</TabsTrigger>
          </TabsList>
          
          <TabsContent value="buy" className="space-y-4">
            <div className="space-y-4">
              <div className="flex items-center justify-between flex-wrap gap-2">
                <label htmlFor="buy-shares" className="text-sm">
                  {getUnitName().charAt(0).toUpperCase() + getUnitName().slice(1)} to Buy
                </label>
                <span className="text-sm text-muted-foreground">
                  Price: {formatCurrency(selectedAsset.price)}
                </span>
              </div>
              
              {/* Maximum purchasable units display */}
              <div className="bg-secondary/50 text-muted-foreground rounded-md p-2 text-sm flex flex-col xs:flex-row items-start xs:items-center justify-between gap-2">
                <div className="flex items-center">
                  <Calculator className="h-4 w-4 mr-2 flex-shrink-0" />
                  <span>You can buy up to:</span>
                </div>
                <div className="font-semibold flex items-center gap-1 ml-6 xs:ml-0">
                  <span>{maxPurchasableUnits}</span>
                  <span>{getUnitName()}</span>
                  <Button 
                    variant="ghost" 
                    size="sm" 
                    className="h-6 px-2 ml-1 text-xs" 
                    onClick={handleMaxUnits}
                  >
                    Use Max
                  </Button>
                </div>
              </div>
              
              <Input
                id="buy-shares"
                type="text"
                value={shares}
                onChange={handleSharesChange}
                placeholder={`Enter number of ${getUnitName()}`}
              />
              <div className="flex flex-wrap items-center gap-2">
                {[10, 25, 50, 100].map((preset) => (
                  <Button
                    key={preset}
                    variant="outline"
                    size="sm"
                    className="h-8 px-2 flex-1"
                    onClick={() => setShares(preset.toString())}
                    disabled={preset > maxPurchasableUnits}
                  >
                    {preset}
                  </Button>
                ))}
              </div>
              <div className="mt-6 space-y-2 text-sm rounded-md bg-secondary p-3">
                <div className="flex justify-between">
                  <span>Cost</span>
                  <span>{formatCurrency(calculateTotal())}</span>
                </div>
                <div className="flex justify-between">
                  <span>Cash Available</span>
                  <span>{formatCurrency(availableCash)}</span>
                </div>
                <div className="flex justify-between">
                  <span>Cash Remaining</span>
                  <span>{formatCurrency(availableCash - calculateTotal())}</span>
                </div>
                <div className="flex justify-between font-bold border-t pt-2">
                  <span>New Position</span>
                  <span>{ownedShares + (parseInt(shares) || 0)} {getUnitName()}</span>
                </div>
              </div>
            </div>
          </TabsContent>
          
          <TabsContent value="sell" className="space-y-4">
            <div className="space-y-4">
              <div className="flex items-center justify-between flex-wrap gap-2">
                <label htmlFor="sell-shares" className="text-sm">
                  {getUnitName().charAt(0).toUpperCase() + getUnitName().slice(1)} to Sell
                </label>
                <span className="text-sm text-muted-foreground">
                  You own: {ownedShares} {getUnitName()}
                </span>
              </div>
              <Input
                id="sell-shares"
                type="text"
                value={shares}
                onChange={handleSharesChange}
                placeholder={`Enter number of ${getUnitName()}`}
              />
              <div className="flex flex-wrap items-center gap-2">
                <Button
                  variant="outline"
                  size="sm"
                  className="flex-1 h-8 px-2"
                  onClick={() => setShares((Math.floor(ownedShares / 4)).toString())}
                  disabled={ownedShares === 0}
                >
                  25%
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  className="flex-1 h-8 px-2"
                  onClick={() => setShares((Math.floor(ownedShares / 2)).toString())}
                  disabled={ownedShares === 0}
                >
                  50%
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  className="flex-1 h-8 px-2"
                  onClick={() => setShares(ownedShares.toString())}
                  disabled={ownedShares === 0}
                >
                  All
                </Button>
              </div>
              <div className="mt-6 space-y-2 text-sm rounded-md bg-secondary p-3">
                <div className="flex justify-between">
                  <span>Sale Value</span>
                  <span>{formatCurrency(calculateTotal())}</span>
                </div>
                <div className="flex justify-between">
                  <span>Current Cash</span>
                  <span>{formatCurrency(availableCash)}</span>
                </div>
                <div className="flex justify-between font-bold border-t pt-2">
                  <span>New Cash Balance</span>
                  <span>{formatCurrency(availableCash + calculateTotal())}</span>
                </div>
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </CardContent>
      <CardFooter className="flex justify-end">
        <Button onClick={handleTrade} disabled={!shares} className="w-full sm:w-auto">
          {tradeType === 'buy' ? 'Buy' : 'Sell'} {getUnitName()}
        </Button>
      </CardFooter>
    </Card>
  );
};

export default TradePanel;