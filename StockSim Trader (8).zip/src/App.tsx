import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import HomePage from "@/pages/HomePage";
import NotFoundPage from "@/pages/NotFoundPage";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";

function App() {
  return (
    <TooltipProvider>
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<HomePage />} />
          {/* Redirect routes to homepage with the appropriate state */}
          <Route path="/learn" element={<Navigate to="/" state={{ activeTab: "learn" }} />} />
          <Route path="/simulate" element={<Navigate to="/" state={{ activeTab: "simulate" }} />} />
          <Route path="/quiz" element={<Navigate to="/" state={{ activeTab: "quiz" }} />} />
          <Route path="/market-insights" element={<Navigate to="/" state={{ activeTab: "insights" }} />} />
          <Route path="*" element={<NotFoundPage />} />
        </Routes>
      </BrowserRouter>
      <Toaster />
    </TooltipProvider>
  );
}

export default App;